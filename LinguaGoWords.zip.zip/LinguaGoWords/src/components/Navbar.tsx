"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { 
  Menu, X, BookOpen, BrainCircuit, ShieldAlert, Award, Star, 
  LayoutDashboard, Heart, GraduationCap, Trophy, UserSquare2, LogOut 
} from "lucide-react";
import AdminAccessModal from "./AdminAccessModal";

export default function Navbar() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [logoClicks, setLogoClicks] = useState(0);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  // Fetch current user details on mount/navigation
  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, [pathname]);

  // Logo 5 times click handler
  const handleLogoClick = () => {
    const clicks = logoClicks + 1;
    setLogoClicks(clicks);
    if (clicks >= 5) {
      setLogoClicks(0);
      setIsAdminModalOpen(true);
    } else {
      // Reset clicks after 3 seconds of inactivity
      const timer = setTimeout(() => setLogoClicks(0), 3000);
      return () => clearTimeout(timer);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.push("/login");
    router.refresh();
  };

  const navItems = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Vocabulary", href: "/vocabulary", icon: BookOpen },
    { name: "Tests", href: "/tests", icon: GraduationCap },
    { name: "Saved", href: "/saved", icon: Heart },
    { name: "IELTS", href: "/ielts", icon: Trophy },
    { name: "AI Mentor", href: "/mentor", icon: BrainCircuit },
    { name: "Premium", href: "/premium", icon: Star },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand Logo with click tracker */}
        <div className="flex items-center gap-6">
          <button
            onClick={handleLogoClick}
            className="flex items-center gap-2 text-left group focus:outline-none"
            title="Click 5 times for Admin Access"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-200 transition group-hover:scale-105">
              <Award className="h-6 w-6 font-bold text-yellow-300" />
            </div>
            <div>
              <span className="block text-lg font-extrabold tracking-tight text-slate-900 leading-none">
                LinguaGo<span className="text-blue-600">Words</span>
              </span>
              <span className="text-[10px] font-medium text-slate-400">
                v1.0.0 {logoClicks > 0 && `(${logoClicks}/5)`}
              </span>
            </div>
          </button>

          {/* Desktop Navigation for authorized users */}
          {user && (
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-semibold transition ${
                      isActive
                        ? "bg-blue-50 text-blue-600"
                        : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {item.name}
                  </Link>
                );
              })}
            </nav>
          )}
        </div>

        {/* Right Action buttons */}
        <div className="hidden md:flex items-center gap-4">
          {loading ? (
            <div className="h-8 w-8 animate-pulse rounded-full bg-slate-200" />
          ) : user ? (
            <div className="flex items-center gap-3">
              {/* If user is Admin, show a subtle shield reminder */}
              {(user.role === "admin" || user.role === "super_admin") && (
                <Link
                  href="/admin"
                  className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 border border-red-100 rounded-lg px-2.5 py-1 hover:bg-red-100 transition"
                >
                  <ShieldAlert className="h-3.5 w-3.5" />
                  Admin
                </Link>
              )}

              {/* User Plan Badge */}
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                user.subscriptionPlan === "IELTS" 
                  ? "bg-purple-100 text-purple-700 border border-purple-200"
                  : user.subscriptionPlan === "Basic"
                  ? "bg-green-100 text-green-700 border border-green-200"
                  : "bg-slate-100 text-slate-600"
              }`}>
                {user.subscriptionPlan} Plan
              </span>

              {/* Profile Shortcut */}
              <Link
                href="/profile"
                className="flex items-center gap-2 group p-1 pr-3 hover:bg-slate-50 rounded-xl transition"
              >
                <img
                  src={user.avatarUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}`}
                  alt={user.fullName}
                  className="h-8 w-8 rounded-full border border-slate-200 bg-slate-100 object-cover"
                />
                <div className="text-left">
                  <span className="block text-xs font-bold text-slate-800 leading-tight group-hover:text-blue-600">
                    {user.fullName}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-medium">
                    @{user.username}
                  </span>
                </div>
              </Link>

              {/* Logout button */}
              <button
                onClick={handleLogout}
                className="p-2 text-slate-400 hover:text-red-500 rounded-xl hover:bg-red-50 transition"
                title="Log Out"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Link
                href="/login"
                className="px-4 py-2 text-sm font-semibold text-slate-700 hover:text-slate-900 transition"
              >
                Sign In
              </Link>
              <Link
                href="/register"
                className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-blue-200 hover:bg-blue-700 transition"
              >
                Join Free
              </Link>
            </div>
          )}
        </div>

        {/* Mobile menu toggle */}
        <div className="flex md:hidden items-center gap-2">
          {user && (
            <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
              user.subscriptionPlan === "IELTS" 
                ? "bg-purple-100 text-purple-700"
                : user.subscriptionPlan === "Basic"
                ? "bg-green-100 text-green-700"
                : "bg-slate-100 text-slate-600"
            }`}>
              {user.subscriptionPlan}
            </span>
          )}

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-600 hover:bg-slate-100 rounded-xl transition"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-3 shadow-lg">
          {user ? (
            <>
              {/* User summary */}
              <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
                <img
                  src={user.avatarUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}`}
                  alt={user.fullName}
                  className="h-10 w-10 rounded-full border border-slate-200 bg-slate-100"
                />
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{user.fullName}</h4>
                  <p className="text-xs text-slate-500">@{user.username} • {user.subscriptionPlan} Plan</p>
                </div>
              </div>

              {/* Nav links */}
              <div className="grid grid-cols-2 gap-2">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = pathname === item.href;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-bold transition ${
                        isActive
                          ? "bg-blue-50 text-blue-600"
                          : "text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      {item.name}
                    </Link>
                  );
                })}
              </div>

              {/* Profile & Admin links */}
              <div className="flex flex-col gap-2 pt-3 border-t border-slate-100">
                {(user.role === "admin" || user.role === "super_admin") && (
                  <Link
                    href="/admin"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center justify-center gap-2 rounded-xl bg-red-50 border border-red-100 py-2.5 text-xs font-bold text-red-600 hover:bg-red-100 transition"
                  >
                    <ShieldAlert className="h-4 w-4" />
                    Admin Control Panel
                  </Link>
                )}
                <Link
                  href="/profile"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
                >
                  <UserSquare2 className="h-4 w-4" />
                  My Profile Settings
                </Link>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    handleLogout();
                  }}
                  className="flex items-center justify-center gap-2 rounded-xl bg-slate-900 py-2.5 text-xs font-bold text-white hover:bg-slate-800 transition"
                >
                  <LogOut className="h-4 w-4" />
                  Log Out
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col gap-2">
              <Link
                href="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-center rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition"
              >
                Sign In
              </Link>
              <Link
                href="/register"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-center rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 transition"
              >
                Join Free Now
              </Link>
            </div>
          )}
        </div>
      )}

      {/* Hidden Admin access code modal */}
      <AdminAccessModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />
    </header>
  );
}
