import { pgTable, text, timestamp, boolean, integer } from "drizzle-orm/pg-core";

// 1. Users Table
export const users = pgTable("users", {
  id: text("id").primaryKey(), // We can use UUID or custom string id
  fullName: text("full_name").notNull(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("user"), // 'user', 'admin', 'super_admin'
  level: text("level").notNull().default("A1"), // 'A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'IELTS'
  subscriptionPlan: text("subscription_plan").notNull().default("Free"), // 'Free', 'Basic', 'IELTS'
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  avatarUrl: text("avatar_url"),
  streak: integer("streak").notNull().default(0),
  banned: boolean("banned").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 2. Subscriptions Table (Logs / status of purchased plans)
export const subscriptions = pgTable("subscriptions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  plan: text("plan").notNull(), // 'Free', 'Basic', 'IELTS'
  status: text("status").notNull(), // 'active', 'expired', 'canceled'
  amount: integer("amount").notNull(), // Amount paid in cents
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
});

// 3. Words Table (Vocabulary database)
export const words = pgTable("words", {
  id: text("id").primaryKey(),
  word: text("word").notNull(),
  translation: text("translation").notNull(),
  pronunciation: text("pronunciation").notNull(),
  wordType: text("word_type").notNull(), // e.g. "Noun", "Verb", "Adjective", "Adverb"
  example1: text("example_1").notNull(),
  example2: text("example_2").notNull(),
  level: text("level").notNull(), // 'A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'IELTS'
  category: text("category").notNull(), // e.g. "Travel", "Business", "General", etc.
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 4. Saved Words Table
export const savedWords = pgTable("saved_words", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  wordId: text("word_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 5. Learned Words Table
export const learnedWords = pgTable("learned_words", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  wordId: text("word_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 6. Tests Table (Configurations or metadata)
export const tests = pgTable("tests", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  level: text("level").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 7. Test Questions Table (Question bank)
export const testQuestions = pgTable("test_questions", {
  id: text("id").primaryKey(),
  testId: text("test_id"), // Optional grouping
  type: text("type").notNull(), // 'multiple_choice', 'translation', 'fill_in_the_blank', 'write_in_english'
  questionText: text("question_text").notNull(),
  options: text("options").notNull(), // Semicolon or comma separated options, or JSON list
  correctAnswer: text("correct_answer").notNull(),
  level: text("level").notNull(), // 'A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'IELTS'
  category: text("category").notNull(), // 'General', 'Academic', 'Vocabulary', etc.
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 8. Test Results Table
export const testResults = pgTable("test_results", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  score: integer("score").notNull(), // Percentage score, e.g. 80
  totalQuestions: integer("total_questions").notNull(),
  correctAnswers: integer("correct_answers").notNull(),
  wrongAnswers: integer("wrong_answers").notNull(),
  accuracy: integer("accuracy").notNull(), // Accuracy percentage
  testType: text("test_type").notNull(), // 'multiple_choice', 'translation', 'fill_in_the_blank', 'write_in_english'
  level: text("level").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 9. Payments Table
export const payments = pgTable("payments", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  amount: integer("amount").notNull(), // In cents
  currency: text("currency").notNull().default("USD"),
  plan: text("plan").notNull(), // 'Basic', 'IELTS'
  status: text("status").notNull(), // 'pending', 'completed', 'failed'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 10. AI Usage Logs
export const aiUsageLogs = pgTable("ai_usage_logs", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  prompt: text("prompt").notNull(),
  response: text("response").notNull(),
  category: text("category").notNull(), // 'Vocabulary', 'Grammar', 'IELTS', 'Writing', 'Speaking'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 11. Admins Table
export const admins = pgTable("admins", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  accessLevel: text("access_level").notNull().default("admin"), // 'admin', 'super_admin'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 12. System Settings Table
export const systemSettings = pgTable("system_settings", {
  id: text("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
