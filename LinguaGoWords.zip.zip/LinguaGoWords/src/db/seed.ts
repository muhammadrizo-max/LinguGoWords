import { db } from "./index";
import { words, testQuestions, systemSettings } from "./schema";

const initialWords = [
  // A1 Level
  {
    id: "w_a1_1",
    word: "Hello",
    translation: "Привет / Поздравление",
    pronunciation: "/həˈləʊ/",
    wordType: "Interjection",
    example1: "Hello! How are you doing today?",
    example2: "She said hello to everyone in the room.",
    level: "A1",
    category: "Social"
  },
  {
    id: "w_a1_2",
    word: "Book",
    translation: "Книга",
    pronunciation: "/bʊk/",
    wordType: "Noun",
    example1: "I am reading an interesting book.",
    example2: "Please put the book back on the shelf.",
    level: "A1",
    category: "General"
  },
  {
    id: "w_a1_3",
    word: "Water",
    translation: "Вода",
    pronunciation: "/ˈwɔː.tər/",
    wordType: "Noun",
    example1: "Could I have a glass of water, please?",
    example2: "Don't forget to drink water after running.",
    level: "A1",
    category: "General"
  },
  {
    id: "w_a1_4",
    word: "Family",
    translation: "Семья",
    pronunciation: "/ˈfæm.əl.i/",
    wordType: "Noun",
    example1: "I love spending time with my family.",
    example2: "How big is your family?",
    level: "A1",
    category: "Family"
  },

  // A2 Level
  {
    id: "w_a2_1",
    word: "Travel",
    translation: "Путешествовать",
    pronunciation: "/ˈtræv.əl/",
    wordType: "Verb",
    example1: "They travel to Spain every summer.",
    example2: "I love to travel and see new places.",
    level: "A2",
    category: "Travel"
  },
  {
    id: "w_a2_2",
    word: "Delicious",
    translation: "Очень вкусный",
    pronunciation: "/dɪˈlɪʃ.əs/",
    wordType: "Adjective",
    example1: "This chocolate cake is absolutely delicious.",
    example2: "The restaurant serves delicious pasta.",
    level: "A2",
    category: "General"
  },

  // B1 Level
  {
    id: "w_b1_1",
    word: "Experience",
    translation: "Опыт / Испытать",
    pronunciation: "/ɪkˈspɪə.ri.əns/",
    wordType: "Noun",
    example1: "She has five years of teaching experience.",
    example2: "It was an amazing experience to climb that mountain.",
    level: "B1",
    category: "General"
  },
  {
    id: "w_b1_2",
    word: "Recommend",
    translation: "Рекомендовать",
    pronunciation: "/ˌrek.əˈmend/",
    wordType: "Verb",
    example1: "Can you recommend a good movie to watch?",
    example2: "My doctor recommended that I exercise more.",
    level: "B1",
    category: "Social"
  },

  // B2 Level
  {
    id: "w_b2_1",
    word: "Challenge",
    translation: "Вызов / Сложная задача",
    pronunciation: "/ˈtʃæl.ɪndʒ/",
    wordType: "Noun",
    example1: "Learning a new language is a big challenge.",
    example2: "He enjoys taking on new challenges at work.",
    level: "B2",
    category: "General"
  },
  {
    id: "w_b2_2",
    word: "Accurate",
    translation: "Точный / Безошибочный",
    pronunciation: "/ˈæk.jə.rət/",
    wordType: "Adjective",
    example1: "Her predictions are always accurate.",
    example2: "Please make sure your report is accurate.",
    level: "B2",
    category: "Academic"
  },

  // C1 Level
  {
    id: "w_c1_1",
    word: "Ambiguous",
    translation: "Двусмысленный / Неоднозначный",
    pronunciation: "/æmˈbɪɡ.ju.əs/",
    wordType: "Adjective",
    example1: "His reply was ambiguous, leaving us confused.",
    example2: "The ending of the novel is intentionally ambiguous.",
    level: "C1",
    category: "Academic"
  },
  {
    id: "w_c1_2",
    word: "Evaluate",
    translation: "Оценивать / Анализировать",
    pronunciation: "/ɪˈvæl.ju.eɪt/",
    wordType: "Verb",
    example1: "We need to evaluate the results of the project.",
    example2: "Teachers evaluate students based on exams and homework.",
    level: "C1",
    category: "Academic"
  },

  // C2 Level
  {
    id: "w_c2_1",
    word: "Ubiquitous",
    translation: "Вездесущий / Повсеместный",
    pronunciation: "/juːˈbɪk.wɪ.təs/",
    wordType: "Adjective",
    example1: "Smartphones have become ubiquitous in modern society.",
    example2: "The brand's logo is ubiquitous across the city.",
    level: "C2",
    category: "General"
  },
  {
    id: "w_c2_2",
    word: "Pragmatic",
    translation: "Прагматичный",
    pronunciation: "/præɡˈmæt.ɪk/",
    wordType: "Adjective",
    example1: "We need a pragmatic approach to solve this issue.",
    example2: "She took a pragmatic decision to cut down unnecessary costs.",
    level: "C2",
    category: "Business"
  },

  // IELTS Level
  {
    id: "w_ielts_1",
    word: "Fluctuate",
    translation: "Колебаться / Быть неустойчивым",
    pronunciation: "/ˈflʌk.tʃu.eɪt/",
    wordType: "Verb",
    example1: "The prices of vegetables fluctuate depending on the season.",
    example2: "The student's performance has fluctuated throughout the year.",
    level: "IELTS",
    category: "Academic"
  },
  {
    id: "w_ielts_2",
    word: "Substantial",
    translation: "Существенный / Значительный",
    pronunciation: "/səbˈstæn.ʃəl/",
    wordType: "Adjective",
    example1: "There has been a substantial increase in online sales.",
    example2: "He made a substantial contribution to the research.",
    level: "IELTS",
    category: "Academic"
  },
  {
    id: "w_ielts_3",
    word: "Detrimental",
    translation: "Вредный / Губительный",
    pronunciation: "/ˌdet.rɪˈmen.təl/",
    wordType: "Adjective",
    example1: "Smoking has a detrimental effect on your health.",
    example2: "These policies could be detrimental to the economy.",
    level: "IELTS",
    category: "Academic"
  },
  {
    id: "w_ielts_4",
    word: "Alleviate",
    translation: "Облегчать / Смягчать",
    pronunciation: "/əˈliː.vi.eɪt/",
    wordType: "Verb",
    example1: "The doctor gave her some medicine to alleviate the pain.",
    example2: "A new highway was built to alleviate traffic congestion.",
    level: "IELTS",
    category: "Academic"
  }
];

const initialQuestions = [
  // A1 Questions
  {
    id: "q_1",
    type: "multiple_choice",
    questionText: "What is the English translation of 'Книга'?",
    options: "Water;Book;Pen;Apple",
    correctAnswer: "Book",
    level: "A1",
    category: "Vocabulary"
  },
  {
    id: "q_2",
    type: "translation",
    questionText: "Translate: 'Hello! How are you?'",
    options: "Привет! Как дела?;Пока! До свидания;Доброе утро;Как тебя зовут?",
    correctAnswer: "Привет! Как дела?",
    level: "A1",
    category: "Vocabulary"
  },
  {
    id: "q_3",
    type: "fill_in_the_blank",
    questionText: "Could I have a glass of ______, please? (Вода)",
    options: "milk;juice;water;tea",
    correctAnswer: "water",
    level: "A1",
    category: "Vocabulary"
  },
  {
    id: "q_4",
    type: "write_in_english",
    questionText: "Write 'Семья' in English (lowercase):",
    options: "family",
    correctAnswer: "family",
    level: "A1",
    category: "Vocabulary"
  },

  // A2 Questions
  {
    id: "q_5",
    type: "multiple_choice",
    questionText: "Choose the correct verb for 'Путешествовать':",
    options: "Travel;Eat;Sleep;Write",
    correctAnswer: "Travel",
    level: "A2",
    category: "Vocabulary"
  },
  {
    id: "q_6",
    type: "translation",
    questionText: "What does 'Delicious' mean?",
    options: "Вкусный;Грустный;Быстрый;Дорогой",
    correctAnswer: "Вкусный",
    level: "A2",
    category: "Vocabulary"
  },

  // B1 Questions
  {
    id: "q_7",
    type: "multiple_choice",
    questionText: "What is the noun form representing personal knowledge or skill gained through doing things?",
    options: "Experiment;Experience;Expectation;Exhibition",
    correctAnswer: "Experience",
    level: "B1",
    category: "Vocabulary"
  },
  {
    id: "q_8",
    type: "fill_in_the_blank",
    questionText: "Can you ______ a good movie to watch? (Рекомендовать)",
    options: "recommend;suggest;require;remember",
    correctAnswer: "recommend",
    level: "B1",
    category: "Vocabulary"
  },

  // B2 Questions
  {
    id: "q_9",
    type: "multiple_choice",
    questionText: "What is the synonym of 'accurate'?",
    options: "Precise;Vague;Wrong;Heavy",
    correctAnswer: "Precise",
    level: "B2",
    category: "Vocabulary"
  },
  {
    id: "q_10",
    type: "translation",
    questionText: "Translate: 'Learning a new language is a big challenge.'",
    options: "Изучение нового языка - это простой шаг;Изучение нового языка - это большой вызов;Языки учить легко;Новый язык приносит счастье",
    correctAnswer: "Изучение нового языка - это большой вызов",
    level: "B2",
    category: "Vocabulary"
  },

  // C1 Questions
  {
    id: "q_11",
    type: "multiple_choice",
    questionText: "Which word means 'having more than one possible meaning'?",
    options: "Ambiguous;Ambitious;Ambidextrous;Anomalous",
    correctAnswer: "Ambiguous",
    level: "C1",
    category: "Vocabulary"
  },

  // C2 Questions
  {
    id: "q_12",
    type: "fill_in_the_blank",
    questionText: "Smartphones have become ______ (повсеместными) in modern society.",
    options: "ubiquitous;unique;unnecessary;united",
    correctAnswer: "ubiquitous",
    level: "C2",
    category: "Vocabulary"
  },

  // IELTS Questions
  {
    id: "q_13",
    type: "multiple_choice",
    questionText: "To rise and fall irregularly in number or amount is to:",
    options: "Fluctuate;Flow;Flex;Flourish",
    correctAnswer: "Fluctuate",
    level: "IELTS",
    category: "Vocabulary"
  },
  {
    id: "q_14",
    type: "multiple_choice",
    questionText: "Which word is a synonym for 'detrimental'?",
    options: "Harmful;Beneficial;Substantial;Temporary",
    correctAnswer: "Harmful",
    level: "IELTS",
    category: "Vocabulary"
  },
  {
    id: "q_15",
    type: "fill_in_the_blank",
    questionText: "The doctor prescribed pills to ______ (облегчить) the severe pain.",
    options: "alleviate;aggravate;allow;allocate",
    correctAnswer: "alleviate",
    level: "IELTS",
    category: "Vocabulary"
  },
  {
    id: "q_16",
    type: "write_in_english",
    questionText: "Write 'Существенный' or 'Значительный' in English (starts with s, ends with l, 11 letters):",
    options: "substantial",
    correctAnswer: "substantial",
    level: "IELTS",
    category: "Vocabulary"
  }
];

const initialSettings = [
  {
    id: "s_1",
    key: "admin_access_code",
    value: "LinguaAdmin2026"
  },
  {
    id: "s_2",
    key: "ai_prompt",
    value: "You are an English Language Mentor for LinguaGoWords. Help the user learn English vocabulary, explain grammar clearly, and provide feedback for IELTS Writing/Speaking. Keep answers encouraging, structured, and informative. Use markdown formatting."
  },
  {
    id: "s_3",
    key: "ai_model",
    value: "gpt-4o-mini"
  }
];

async function seed() {
  console.log("Seeding started...");

  // Seed Words
  for (const w of initialWords) {
    await db.insert(words).values(w).onConflictDoNothing({ target: words.id });
  }
  console.log(`Seeded ${initialWords.length} words.`);

  // Seed Test Questions
  for (const q of initialQuestions) {
    await db.insert(testQuestions).values(q).onConflictDoNothing({ target: testQuestions.id });
  }
  console.log(`Seeded ${initialQuestions.length} test questions.`);

  // Seed Settings
  for (const s of initialSettings) {
    await db.insert(systemSettings).values(s).onConflictDoNothing({ target: systemSettings.key });
  }
  console.log(`Seeded system settings.`);

  console.log("Seeding completed successfully!");
}

seed().catch(err => {
  console.error("Seeding failed:", err);
});
