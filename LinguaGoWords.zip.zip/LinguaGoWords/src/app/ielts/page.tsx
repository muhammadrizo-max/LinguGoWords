"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  Trophy, BookOpen, PenTool, Headphones, Mic, CheckCircle2, 
  ArrowRight, Award, RefreshCw, Star, Info, Play, Timer, Loader2 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function IeltsPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("reading"); // 'reading', 'writing', 'listening', 'speaking'

  const router = useRouter();

  // Reading answers state
  const [readingAnswers, setReadingAnswers] = useState<Record<string, string>>({});
  const [readingChecked, setReadingFinished] = useState(false);
  const [readingScore, setReadingScore] = useState(0);

  // Writing essay state
  const [essayText, setEssayText] = useState("");
  const [essaySubmitted, setEssaySubmitted] = useState(false);

  // Listening state
  const [listeningAnswers, setListeningAnswers] = useState<Record<string, string>>({});
  const [listeningChecked, setListeningChecked] = useState(false);
  const [listeningScore, setListeningScore] = useState(0);

  // Speaking state (prep timer)
  const [prepTimer, setPrepTimer] = useState(60);
  const [timerActive, setTimerActive] = useState(false);

  useEffect(() => {
    let interval: any;
    if (timerActive && prepTimer > 0) {
      interval = setInterval(() => {
        setPrepTimer(prev => prev - 1);
      }, 1000);
    } else if (prepTimer === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, prepTimer]);

  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        router.push("/login");
      }
    } catch {
      router.push("/login");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  // Subscription verification
  const isIeltsLocked = () => {
    if (!user) return true;
    if (user.role === "admin" || user.role === "super_admin") return false;
    return user.subscriptionPlan !== "IELTS";
  };

  const handleCheckReading = () => {
    let score = 0;
    if (readingAnswers["q1"] === "B") score++;
    if (readingAnswers["q2"] === "A") score++;
    if (readingAnswers["q3"] === "C") score++;
    
    setReadingScore(score);
    setReadingFinished(true);
  };

  const handleCheckListening = () => {
    let score = 0;
    if (listeningAnswers["q1"]?.toLowerCase().trim() === "substantial") score++;
    if (listeningAnswers["q2"]?.toLowerCase().trim() === "fluctuate") score++;
    
    setListeningScore(score);
    setListeningChecked(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
          <p className="text-sm text-slate-500">Checking IELTS subscription authorization...</p>
        </div>
      </div>
    );
  }

  // Locked Screen
  if (isIeltsLocked()) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
        <Navbar />
        <main className="mx-auto max-w-4xl w-full px-4 sm:px-6 lg:px-8 mt-12">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 sm:p-12 text-center shadow-md space-y-6">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-purple-50 text-purple-600 border border-purple-100">
              <Trophy className="h-8 w-8" />
            </div>
            
            <div className="space-y-2 max-w-lg mx-auto">
              <h2 className="text-2xl font-black text-slate-950">IELTS Specialized Module</h2>
              <p className="text-sm text-slate-500 leading-relaxed">
                The comprehensive IELTS training program (including customized modules for Reading, Writing, Listening, Speaking, and AI writing correction) is exclusive to <strong className="text-purple-600 font-extrabold">IELTS Master</strong> tier subscribers.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl max-w-md mx-auto text-left space-y-2 border border-slate-100 text-xs text-slate-600">
              <p className="font-bold text-slate-800">💎 Upgrade to IELTS Master to unlock:</p>
              <p>• Academic Reading comprehension tests with automated scoring</p>
              <p>• Essay feedback engine and professional Band 8.5 models</p>
              <p>• Advanced audio transcript drills</p>
              <p>• Speaking Part 2 Cue cards with prep timers</p>
            </div>

            <div className="pt-2">
              <Link
                href="/premium"
                className="inline-flex items-center gap-1.5 rounded-xl bg-purple-600 px-6 py-3.5 text-xs font-bold text-white shadow-md shadow-purple-100 hover:bg-purple-700 transition"
              >
                <Star className="h-4 w-4 text-yellow-300" />
                View Subscription Plans
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-5xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Module Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <Trophy className="h-6 w-6 text-purple-600" />
              IELTS Graded Preparation Center
            </h1>
            <p className="text-slate-500 text-xs mt-1">
              Refine your Academic IELTS credentials with target score templates and automated mock review.
            </p>
          </div>
          <span className="bg-purple-100 text-purple-700 font-extrabold text-xs px-3 py-1.5 rounded-full border border-purple-200">
            👑 IELTS Master Access
          </span>
        </div>

        {/* Core Skill Selector Tabs */}
        <div className="bg-white rounded-2xl p-1.5 border border-slate-200 shadow-3xs flex">
          {[
            { id: "reading", name: "Reading Mock", icon: BookOpen },
            { id: "writing", name: "Writing Task 2", icon: PenTool },
            { id: "listening", name: "Listening Mock", icon: Headphones },
            { id: "speaking", name: "Speaking Cue", icon: Mic },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-bold transition ${
                  isSelected
                    ? "bg-purple-600 text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="hidden sm:inline">{tab.name}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: READING SECTION */}
        {activeTab === "reading" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Passage column */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-3xs space-y-4 max-h-[500px] overflow-y-auto">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Passage Section 1</span>
              <h3 className="text-lg font-black text-slate-950">The Impact of Ubiquitous Technology on Academic Performance</h3>
              
              <div className="text-xs text-slate-600 leading-relaxed space-y-3">
                <p>
                  In the contemporary era, technological tools have become entirely ubiquitous. Across global universities, smartphones, tablets, and wireless laptops are fundamental pillars of educational delivery. However, critics argue that these substantial tools may act as detrimental distractions, causing student performance to fluctuate throughout the academic year.
                </p>
                <p>
                  A research study conducted recently evaluate that undergraduate students who utilized electronic laptops purely for note-taking during lectures logged a substantial decrease in factual memory recall. The explanation lies in the cognitive cognitive load; students who transcribe lectures word-for-word fail to evaluate the underlying concepts pragmatically.
                </p>
                <p>
                  To alleviate these unfavorable consequences, multiple institutions recommend implementing structural regulations, such as electronic-free lecture slots or gamified quizzes, which re-engage student focus dynamically.
                </p>
              </div>
            </div>

            {/* Right Question column */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-3xs space-y-5">
              <h4 className="text-xs font-bold text-purple-600 uppercase tracking-widest">Graded Comprehension Quiz</h4>

              <div className="space-y-4 text-xs">
                
                {/* Q1 */}
                <div className="space-y-2">
                  <p className="font-bold text-slate-800">1. What does the word "ubiquitous" mean in context?</p>
                  <div className="space-y-1.5 pl-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="r_q1" value="A" onChange={() => setReadingAnswers(prev => ({...prev, q1: "A"}))} checked={readingAnswers.q1 === "A"} disabled={readingChecked} />
                      <span>A) Extremely expensive</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="r_q1" value="B" onChange={() => setReadingAnswers(prev => ({...prev, q1: "B"}))} checked={readingAnswers.q1 === "B"} disabled={readingChecked} />
                      <span>B) Omnipresent / found everywhere</span>
                    </label>
                  </div>
                </div>

                {/* Q2 */}
                <div className="space-y-2">
                  <p className="font-bold text-slate-800">2. Word-for-word lecture transcribing can lead to:</p>
                  <div className="space-y-1.5 pl-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="r_q2" value="A" onChange={() => setReadingAnswers(prev => ({...prev, q2: "A"}))} checked={readingAnswers.q2 === "A"} disabled={readingChecked} />
                      <span>A) Lower factual recall</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="r_q2" value="B" onChange={() => setReadingAnswers(prev => ({...prev, q2: "B"}))} checked={readingAnswers.q2 === "B"} disabled={readingChecked} />
                      <span>B) Superb analytical capabilities</span>
                    </label>
                  </div>
                </div>

                {/* Q3 */}
                <div className="space-y-2">
                  <p className="font-bold text-slate-800">3. What is recommended to alleviate lecture distractions?</p>
                  <div className="space-y-1.5 pl-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="r_q3" value="A" onChange={() => setReadingAnswers(prev => ({...prev, q3: "A"}))} checked={readingAnswers.q3 === "A"} disabled={readingChecked} />
                      <span>A) Banning smartphones entirely</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="r_q3" value="C" onChange={() => setReadingAnswers(prev => ({...prev, q3: "C"}))} checked={readingAnswers.q3 === "C"} disabled={readingChecked} />
                      <span>C) Structural regulations (e.g. device-free times)</span>
                    </label>
                  </div>
                </div>

              </div>

              {readingChecked ? (
                <div className="bg-purple-50 p-4 rounded-2xl text-center space-y-2">
                  <h5 className="text-sm font-bold text-purple-700">Quiz Completed!</h5>
                  <p className="text-xs text-slate-600">Your score: <strong className="font-extrabold text-purple-700">{readingScore} / 3</strong></p>
                  <button 
                    onClick={() => {
                      setReadingFinished(false);
                      setReadingAnswers({});
                    }}
                    className="mt-1 text-[10px] font-bold text-purple-600 underline"
                  >
                    Try Again
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleCheckReading}
                  disabled={!readingAnswers.q1 || !readingAnswers.q2 || !readingAnswers.q3}
                  className="w-full rounded-xl bg-purple-600 hover:bg-purple-700 text-white py-2.5 text-xs font-bold transition disabled:opacity-30"
                >
                  Submit & Score Answers
                </button>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: WRITING ESSAY */}
        {activeTab === "writing" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Input prompt & Editor */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-3xs space-y-4">
              <span className="text-[10px] font-bold text-slate-400 uppercase block">Academic Task 2 Essay</span>
              
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs text-slate-700 space-y-2">
                <p className="font-extrabold text-slate-800">Prompt:</p>
                <p className="italic">
                  &ldquo;Smartphones and digital tablets are becoming ubiquitous in primary education. Do the substantial benefits of these devices in class outweigh their detrimental distraction aspects?&rdquo;
                </p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Write your essay (Minimum 150 words):</label>
                  <span className="text-[10px] text-slate-400 font-bold">{essayText.split(/\s+/).filter(Boolean).length} words</span>
                </div>
                <textarea
                  value={essayText}
                  onChange={(e) => setEssayText(e.target.value)}
                  placeholder="In modern times, electronic gadgets are increasingly utilized..."
                  className="w-full min-h-[220px] rounded-2xl border border-slate-200 p-4 text-xs text-slate-800 focus:border-purple-600 focus:ring-1 focus:ring-purple-600 outline-none transition bg-white"
                  disabled={essaySubmitted}
                />
              </div>

              {essaySubmitted ? (
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setEssaySubmitted(false);
                      setEssayText("");
                    }}
                    className="flex-1 rounded-xl border border-slate-200 text-slate-600 py-3 text-xs font-bold hover:bg-slate-50 transition"
                  >
                    Reset Essay
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setEssaySubmitted(true)}
                  disabled={!essayText.trim()}
                  className="w-full rounded-xl bg-purple-600 hover:bg-purple-700 text-white py-3 text-xs font-bold transition disabled:opacity-30"
                >
                  Analyze & Grade Essay
                </button>
              )}
            </div>

            {/* AI Analyzer Result & Model Essay */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-3xs space-y-5 overflow-y-auto max-h-[500px]">
              {essaySubmitted ? (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="p-4 bg-green-50 border border-green-100 rounded-2xl text-center space-y-1">
                    <span className="text-[10px] font-bold text-green-600 uppercase tracking-widest block">Estimated Band Rating</span>
                    <h3 className="text-2xl font-black text-green-700">Band 7.5 (Academic)</h3>
                    <p className="text-[11px] text-slate-500">Superb vocabulary range! Great use of &quot;ubiquitous&quot; and &quot;detrimental&quot; collocations.</p>
                  </div>

                  <div className="space-y-2 text-xs">
                    <h4 className="font-extrabold text-slate-800">💡 Constructive Feedback Recommendations:</h4>
                    <p className="text-slate-600 leading-relaxed">
                      • **Lexical resource:** High standard. To boost score further, ensure a clear transition between opposing viewpoints using transitional adverbs like *Nevertheless* and *Conversely*.
                    </p>
                    <p className="text-slate-600 leading-relaxed">
                      • **Grammar range:** Excellent. Try adding a conditional sentence (*"If devices were banned entirely, students might..."*) to satisfy grammatical complex parameters.
                    </p>
                  </div>

                  <div className="border-t border-slate-100 pt-3 space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Model Band 8.5 Answer Sample</span>
                    <p className="text-[11px] text-slate-500 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100 italic">
                      In contemporary educational paradigms, the ubiquity of technological tools has elicited fierce controversy. While some commentators argue that these gadgets exert a detrimental influence on student attentiveness, I firmly believe that their substantial educational benefits are paramount. By integrating interactive applications, teachers can alleviate student boredom and deliver personalized lexical resources, which far outweighs minor digital distractions...
                    </p>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3 text-slate-400">
                  <PenTool className="h-8 w-8 text-slate-300" />
                  <div>
                    <h4 className="font-bold text-slate-700 text-sm">Waiting for Submission</h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs">Type or paste your IELTS essay on the left and click analyze to trigger immediate feedback, score estimation, and model samples.</p>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 3: LISTENING SECTION */}
        {activeTab === "listening" && (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-3xs space-y-6">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Section 4 Academic Lecture</span>
            
            {/* Audio player simulator */}
            <div className="bg-slate-900 text-white p-5 rounded-2xl flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => alert("🔈 Simulated Audio Playing: 'This lecture explores vocabulary fluctuation and substantial advancements in green technologies...'")}
                  className="h-12 w-12 rounded-full bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-center transition shrink-0"
                >
                  <Play className="h-5 w-5 fill-white pl-0.5" />
                </button>
                <div>
                  <h4 className="text-sm font-bold text-white leading-tight">IELTS Listening Track 04.mp3</h4>
                  <p className="text-[11px] text-slate-400">Duration: 2:45 • High quality lecture stream</p>
                </div>
              </div>
              <span className="text-xs font-mono text-slate-400 bg-white/10 px-2.5 py-1 rounded-md">0:00 / 2:45</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
              {/* Question list */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Fill in the missing words from the transcript:</h4>
                
                <div className="space-y-3 text-xs">
                  <div className="space-y-1">
                    <p className="text-slate-600">
                      1. &quot;The team reported a <strong className="text-purple-600">_______</strong> (значительный) increase in the development parameter.&quot;
                    </p>
                    <input
                      type="text"
                      placeholder="Type correct word..."
                      value={listeningAnswers.q1 || ""}
                      onChange={(e) => setListeningAnswers(prev => ({...prev, q1: e.target.value}))}
                      className="rounded-xl border border-slate-200 px-3.5 py-2 text-xs focus:border-purple-600 outline-none w-full bg-white"
                      disabled={listeningChecked}
                    />
                  </div>

                  <div className="space-y-1">
                    <p className="text-slate-600">
                      2. &quot;Due to climatic weather variables, annual crop productions <strong className="text-purple-600">_______</strong> (колеблются) randomly.&quot;
                    </p>
                    <input
                      type="text"
                      placeholder="Type correct word..."
                      value={listeningAnswers.q2 || ""}
                      onChange={(e) => setListeningAnswers(prev => ({...prev, q2: e.target.value}))}
                      className="rounded-xl border border-slate-200 px-3.5 py-2 text-xs focus:border-purple-600 outline-none w-full bg-white"
                      disabled={listeningChecked}
                    />
                  </div>
                </div>

                {listeningChecked ? (
                  <div className="p-4 bg-purple-50 text-purple-700 rounded-2xl text-center text-xs font-bold space-y-1">
                    <p>Track Graded successfully!</p>
                    <p>Score: {listeningScore} / 2</p>
                    <button 
                      onClick={() => {
                        setListeningChecked(false);
                        setListeningAnswers({});
                      }}
                      className="underline block mx-auto text-[10px] mt-1 text-purple-600"
                    >
                      Reset Audio Drill
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleCheckListening}
                    className="w-full rounded-xl bg-purple-600 hover:bg-purple-700 text-white py-2.5 text-xs font-bold transition"
                  >
                    Verify Answers
                  </button>
                )}
              </div>

              {/* Explanations */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-xs text-slate-600 leading-relaxed space-y-3">
                <p className="font-bold text-slate-800">📚 Audio Script Hints:</p>
                <p>
                  • **Hint 1:** Listen carefully at minute 1:05. The speaker uses the word *substantial* when discussing scientific expansion numbers.
                </p>
                <p>
                  • **Hint 2:** Watch for spelling at minute 2:10. The verb *fluctuate* is used to characterize continuous crop variability.
                </p>
              </div>
            </div>

          </div>
        )}

        {/* TAB 4: SPEAKING SECTION */}
        {activeTab === "speaking" && (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-3xs space-y-6">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Speaking Cue Card (Part 2)</span>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Cue Card presentation */}
              <div className="space-y-4">
                <div className="bg-purple-50 border border-purple-100 p-5 rounded-2xl space-y-3 text-xs">
                  <h4 className="font-extrabold text-purple-800 text-sm">Describe a beautiful place you visited that had a profound effect on you.</h4>
                  <p className="text-slate-600 font-bold">You should say:</p>
                  <ul className="list-disc list-inside space-y-1 text-slate-500 font-medium">
                    <li>Where this place is located</li>
                    <li>When you traveled there</li>
                    <li>What you did while visiting</li>
                    <li>And explain why it made such a substantial impression on you.</li>
                  </ul>
                </div>

                {/* Prep Timer tool */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Timer className="h-5 w-5 text-purple-600" />
                    <div>
                      <span className="block text-xs font-bold text-slate-800">Preparation Clock</span>
                      <span className="text-[10px] text-slate-400">1 minute to brainstorm notes</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-sm font-mono font-bold text-slate-900">{prepTimer}s</span>
                    <button
                      onClick={() => setTimerActive(!timerActive)}
                      className="px-3 py-1.5 rounded-lg bg-purple-600 text-white text-[10px] font-bold hover:bg-purple-700 transition"
                    >
                      {timerActive ? "Pause" : "Start"}
                    </button>
                    <button
                      onClick={() => {
                        setTimerActive(false);
                        setPrepTimer(60);
                      }}
                      className="text-[10px] font-bold text-slate-400 hover:text-slate-600 transition"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              </div>

              {/* Tips & Key Vocabularies */}
              <div className="space-y-4 text-xs leading-relaxed text-slate-600">
                <h4 className="font-bold text-slate-800">🌟 Premium Speaking Vocabulary Booster:</h4>
                <p>Include these advanced collocations in your 2-minute speech to secure a Band 8+ in Lexical Resource parameters:</p>
                
                <div className="space-y-2">
                  <p>• <strong className="text-purple-600">Profound effect</strong> — &quot;The silence of the vast mountains had a profound effect on my mental clarity.&quot;</p>
                  <p>• <strong className="text-purple-600">Spectacular scenery</strong> — &quot;It features a spectacular scenery of rolling green hills.&quot;</p>
                  <p>• <strong className="text-purple-600">Unwind and recharge</strong> — &quot;I traveled there primarily to unwind and recharge my energies.&quot;</p>
                  <p>• <strong className="text-purple-600">Substantial memories</strong> — &quot;The hospitality of the locals left substantial memories.&quot;</p>
                </div>

                <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-100 text-[11px] text-blue-700 flex gap-2">
                  <Info className="h-4.5 w-4.5 shrink-0" />
                  <p>Tip: Focus on speak fluently. Use connecting keywords like *As a matter of fact*, *Moving on to*, and *Ultimately* to link your descriptive sentences.</p>
                </div>
              </div>

            </div>
          </div>
        )}

      </main>
    </div>
  );
}
