"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  Volume2, Heart, CheckCircle, ArrowRight, ArrowLeft, Lock, Star, 
  HelpCircle, RefreshCw, BookmarkCheck, Search, SlidersHorizontal, Award 
} from "lucide-react";
import Navbar from "@/components/Navbar";

const AVAILABLE_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2", "IELTS"];
const AVAILABLE_CATEGORIES = ["All", "General", "Social", "Family", "Travel", "Academic", "Business"];

export default function VocabularyPage() {
  const [user, setUser] = useState<any>(null);
  const [words, setWords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [selectedLevel, setSelectedLevel] = useState("A1");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");

  const [savingId, setSavingId] = useState<string | null>(null);
  const [learningId, setLearningId] = useState<string | null>(null);

  const router = useRouter();

  // Fetch current user details
  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        router.push("/login");
      }
    } catch {
      router.push("/login");
    }
  };

  // Fetch words based on filters
  const fetchWords = async () => {
    setLoading(true);
    try {
      const categoryParam = selectedCategory === "All" ? "" : selectedCategory;
      const res = await fetch(`/api/vocabulary?level=${selectedLevel}&category=${categoryParam}`);
      if (res.ok) {
        const data = await res.json();
        setWords(data.words || []);
        setCurrentIndex(0);
      }
    } catch (err) {
      console.error("Error fetching words:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  useEffect(() => {
    if (user) {
      fetchWords();
    }
  }, [user, selectedLevel, selectedCategory]);

  // Determine if level is locked based on subscription tier
  const isLevelLocked = (level: string) => {
    if (!user) return true;
    const plan = user.subscriptionPlan;
    if (plan === "IELTS" || user.role === "admin" || user.role === "super_admin") return false;
    
    if (plan === "Basic") {
      // Basic plan gets A1, A2, B1
      return !["A1", "A2", "B1"].includes(level);
    }
    
    // Free plan gets A1 only
    return level !== "A1";
  };

  const currentLevelLocked = isLevelLocked(selectedLevel);

  // Play audio pronunciation using speech synthesis
  const handleListen = (textToSpeak: string) => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      // Cancel previous utterances
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = "en-US";
      utterance.rate = 0.85; // Slightly slower for language learners
      window.speechSynthesis.speak(utterance);
    } else {
      alert("Text-to-speech is not supported in your browser.");
    }
  };

  // Save/Unsave word
  const toggleSaveWord = async (word: any) => {
    if (!user) return;
    setSavingId(word.id);
    const action = word.isSaved ? "unsave" : "save";

    try {
      const res = await fetch("/api/vocabulary/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wordId: word.id, action }),
      });

      if (res.ok) {
        // Update word status locally
        setWords(prev => 
          prev.map(w => w.id === word.id ? { ...w, isSaved: !word.isSaved } : w)
        );
      }
    } catch (err) {
      console.error("Error saving word:", err);
    } finally {
      setSavingId(null);
    }
  };

  // Toggle Learned word
  const toggleMarkLearned = async (word: any) => {
    if (!user) return;
    setLearningId(word.id);
    const action = word.isLearned ? "unlearn" : "learn";

    try {
      const res = await fetch("/api/vocabulary/learned", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wordId: word.id, action }),
      });

      if (res.ok) {
        // Update word status locally
        setWords(prev => 
          prev.map(w => w.id === word.id ? { ...w, isLearned: !word.isLearned } : w)
        );
      }
    } catch (err) {
      console.error("Error toggling learned:", err);
    } finally {
      setLearningId(null);
    }
  };

  const handleNext = () => {
    if (words.length > 0) {
      setCurrentIndex((prev) => (prev + 1) % words.length);
    }
  };

  const handlePrev = () => {
    if (words.length > 0) {
      setCurrentIndex((prev) => (prev - 1 + words.length) % words.length);
    }
  };

  // Apply quick search inside current loaded list
  const filteredWords = words.filter(w => 
    w.word.toLowerCase().includes(searchTerm.toLowerCase()) || 
    w.translation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeWord = filteredWords[currentIndex];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-4xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Module Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <Award className="h-6 w-6 text-blue-600" />
              Vocabulary Graded Flashcards
            </h1>
            <p className="text-slate-500 text-xs mt-1">
              Select your English standard level, filter by topic, and master new vocabulary with direct audio.
            </p>
          </div>

          {/* Plan restriction guide alert */}
          {user && (
            <span className="text-[11px] font-bold text-slate-500 bg-slate-100 border border-slate-200 px-3 py-1 rounded-xl">
              Current Plan: <strong className="text-blue-600 font-bold">{user.subscriptionPlan}</strong>
            </span>
          )}
        </div>

        {/* Level Selector Tabs */}
        <div className="bg-white rounded-2xl p-2.5 border border-slate-200 shadow-xs flex flex-wrap gap-1">
          {AVAILABLE_LEVELS.map((lvl) => {
            const locked = isLevelLocked(lvl);
            const isSelected = selectedLevel === lvl;

            return (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`flex-1 min-w-[70px] flex items-center justify-center gap-1 py-2 px-3 rounded-xl text-xs font-bold transition ${
                  isSelected
                    ? "bg-blue-600 text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                {locked && <Lock className="h-3 w-3 text-slate-400 shrink-0" />}
                {lvl}
              </button>
            );
          })}
        </div>

        {/* Category Filters */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            <SlidersHorizontal className="h-4 w-4 text-slate-400 shrink-0" />
            {AVAILABLE_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-lg border transition shrink-0 ${
                  selectedCategory === cat
                    ? "bg-slate-900 border-slate-900 text-white"
                    : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Quick search input */}
          <div className="relative w-full sm:w-64 shrink-0">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search current word..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-slate-200 pl-9 pr-4 py-1.5 text-xs text-slate-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-none transition bg-white"
            />
          </div>
        </div>

        {/* Level Locked Screen */}
        {currentLevelLocked ? (
          <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-xs space-y-4">
            <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-500 mb-2 border border-amber-100">
              <Lock className="h-7 w-7" />
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">
              Unlock {selectedLevel} Level Vocabulary
            </h3>
            <p className="text-slate-500 text-sm max-w-md mx-auto leading-relaxed">
              Level <strong className="font-bold text-slate-700">{selectedLevel}</strong> is a Premium feature. You are currently on the <strong className="font-bold text-slate-700">{user?.subscriptionPlan || "Free"}</strong> Plan. Upgrade to unlock full vocabulary cards, IELTS tests, and the AI Mentor.
            </p>
            <div className="pt-2">
              <Link
                href="/premium"
                className="inline-flex items-center gap-1.5 rounded-xl bg-blue-600 px-6 py-3 text-xs font-bold text-white shadow-md shadow-blue-200 hover:bg-blue-700 transition"
              >
                <Star className="h-4 w-4 text-yellow-300" />
                View Premium Plans
              </Link>
            </div>
          </div>
        ) : loading ? (
          /* Loading skeleton */
          <div className="rounded-3xl bg-white border border-slate-200 p-8 sm:p-12 shadow-xs space-y-6 text-center animate-pulse">
            <div className="h-8 w-48 bg-slate-200 rounded-lg mx-auto" />
            <div className="h-4 w-32 bg-slate-100 rounded-lg mx-auto" />
            <div className="h-24 bg-slate-50 rounded-xl" />
          </div>
        ) : filteredWords.length === 0 ? (
          /* Empty State */
          <div className="rounded-3xl border border-slate-200 bg-white p-12 text-center shadow-xs">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-400 mb-4">
              <HelpCircle className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-slate-800">No vocabulary found</h3>
            <p className="text-slate-400 text-xs mt-1">
              There are no matching words for level "{selectedLevel}" in category "{selectedCategory}".
            </p>
            <button
              onClick={() => {
                setSelectedLevel("A1");
                setSelectedCategory("All");
                setSearchTerm("");
              }}
              className="mt-4 rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 transition"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          /* Word Card Display */
          <div className="space-y-6">
            <div className="rounded-3xl bg-white border-2 border-slate-100 p-6 sm:p-10 shadow-lg relative overflow-hidden">
              {/* Top metadata tags */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <span className="bg-blue-600 text-white font-extrabold text-[10px] px-2.5 py-0.5 rounded-lg uppercase">
                    Level {activeWord.level}
                  </span>
                  <span className="bg-slate-100 text-slate-600 font-semibold text-[10px] px-2.5 py-0.5 rounded-lg uppercase">
                    {activeWord.category}
                  </span>
                </div>
                <span className="text-xs text-slate-400 font-bold">
                  Card {currentIndex + 1} of {filteredWords.length}
                </span>
              </div>

              {/* Main Word Body */}
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center gap-2.5">
                  <h2 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight">
                    {activeWord.word}
                  </h2>
                  
                  {/* Pronunciation speech synthesis trigger */}
                  <button
                    onClick={() => handleListen(activeWord.word)}
                    className="p-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-full transition"
                    title="Listen Pronunciation"
                  >
                    <Volume2 className="h-5 w-5 sm:h-6 sm:w-6" />
                  </button>
                </div>

                <div className="flex items-center justify-center gap-2 text-sm text-slate-500 font-medium">
                  <span className="italic text-blue-600 font-semibold">{activeWord.wordType}</span>
                  <span>•</span>
                  <span>{activeWord.pronunciation}</span>
                </div>

                {/* Translation translation panel */}
                <div className="py-4 px-6 bg-slate-50 rounded-2xl inline-block max-w-md">
                  <span className="text-xs text-slate-400 uppercase tracking-wider block font-semibold mb-1">Translation</span>
                  <p className="text-lg font-bold text-slate-900">{activeWord.translation}</p>
                </div>
              </div>

              {/* Real Sentence Examples */}
              <div className="mt-8 pt-6 border-t border-slate-100 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Contextual Examples</h4>
                
                <div className="space-y-3">
                  {activeWord.example1 && (
                    <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100 text-sm">
                      <p className="text-slate-800 font-medium">1. &ldquo;{activeWord.example1}&rdquo;</p>
                    </div>
                  )}
                  {activeWord.example2 && (
                    <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100 text-sm">
                      <p className="text-slate-800 font-medium">2. &ldquo;{activeWord.example2}&rdquo;</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons on Word Card */}
              <div className="mt-8 pt-6 border-t border-slate-100 flex flex-wrap gap-3 items-center justify-between">
                
                {/* Save toggling */}
                <button
                  onClick={() => toggleSaveWord(activeWord)}
                  disabled={savingId !== null}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold border transition ${
                    activeWord.isSaved
                      ? "bg-rose-50 border-rose-200 text-rose-600 hover:bg-rose-100"
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <Heart className={`h-4.5 w-4.5 ${activeWord.isSaved ? "fill-rose-500 text-rose-500" : "text-slate-400"}`} />
                  {activeWord.isSaved ? "Saved in List" : "Save Word"}
                </button>

                {/* Mark Learned toggling */}
                <button
                  onClick={() => toggleMarkLearned(activeWord)}
                  disabled={learningId !== null}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold border transition ${
                    activeWord.isLearned
                      ? "bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <CheckCircle className={`h-4.5 w-4.5 ${activeWord.isLearned ? "fill-green-500 text-green-500" : "text-slate-400"}`} />
                  {activeWord.isLearned ? "Marked Learned" : "Mark Learned"}
                </button>

                {/* Direct audio speak */}
                <button
                  onClick={() => handleListen(activeWord.word)}
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 px-5 py-2.5 text-xs font-bold text-white hover:bg-slate-800 transition"
                >
                  <Volume2 className="h-4 w-4" />
                  Listen Audio
                </button>

              </div>
            </div>

            {/* Pagination / Next Prevs Navigation */}
            <div className="flex items-center justify-between">
              <button
                onClick={handlePrev}
                className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl px-4 py-2.5 transition"
              >
                <ArrowLeft className="h-4 w-4" />
                Previous Word
              </button>

              <button
                onClick={handleNext}
                className="flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 border border-blue-100 rounded-xl px-4 py-2.5 transition"
              >
                Next Word
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
