"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  ShieldAlert, Users, BookOpen, GraduationCap, DollarSign, 
  Megaphone, BrainCircuit, Settings, ArrowLeft, Search, 
  Trash2, Plus, Edit, Ban, UserCheck, Star, Sparkles, Loader2 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function AdminPanelPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeModule, setActiveTab] = useState("analytics"); // analytics, users, vocabulary, tests, payments, broadcast, ai_settings

  // Global administrative state
  const [analytics, setAnalytics] = useState<any>(null);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [allWords, setAllWords] = useState<any[]>([]);
  const [allQuestions, setAllQuestions] = useState<any[]>([]);
  const [allPayments, setAllPayments] = useState<any[]>([]);

  // Sub-modules Search
  const [userSearch, setUserSearch] = useState("");
  const [wordSearch, setWordSearch] = useState("");

  // Sub-forms state (Add word)
  const [newWord, setNewWord] = useState({
    word: "", translation: "", pronunciation: "", wordType: "Noun",
    example1: "", example2: "", level: "A1", category: "General"
  });
  
  // Add question state
  const [newQuestion, setNewQuestion] = useState({
    type: "multiple_choice", questionText: "", options: "Option A;Option B;Option C;Option D",
    correctAnswer: "Option A", level: "A1", category: "Vocabulary"
  });

  // Broadcast state
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [broadcastTarget, setBroadcastTarget] = useState("all");
  const [broadcastSuccess, setBroadcastSuccess] = useState("");

  // System Configs state
  const [adminCodeSetting, setAdminCodeSetting] = useState("LinguaAdmin2026");
  const [aiPromptSetting, setAiPromptSetting] = useState("");
  const [aiModelSetting, setAiModelSetting] = useState("gpt-4o-mini");
  const [configsSuccess, setConfigsSuccess] = useState("");

  const router = useRouter();

  // Load everything
  const loadAdminData = async () => {
    try {
      // 1. Verify User
      const uRes = await fetch("/api/auth/me");
      if (!uRes.ok) {
        router.push("/login");
        return;
      }
      const uData = await uRes.json();
      if (uData.user.role !== "admin" && uData.user.role !== "super_admin") {
        // Forbidden, push to dashboard
        router.push("/dashboard");
        return;
      }
      setUser(uData.user);

      // 2. Load system configurations & analytics
      const configRes = await fetch("/api/admin/settings");
      if (configRes.ok) {
        const configData = await configRes.json();
        setAnalytics(configData.analytics);
        setAllPayments(configData.payments || []);

        const settings = configData.settings || [];
        const codeS = settings.find((s: any) => s.key === "admin_access_code")?.value || "LinguaAdmin2026";
        const promptS = settings.find((s: any) => s.key === "ai_prompt")?.value || "";
        const modelS = settings.find((s: any) => s.key === "ai_model")?.value || "gpt-4o-mini";

        setAdminCodeSetting(codeS);
        setAiPromptSetting(promptS);
        setAiModelSetting(modelS);
      }

      // 3. Load users
      const usersRes = await fetch("/api/admin/users");
      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setAllUsers(usersData.users || []);
      }

      // 4. Load words
      const wordsRes = await fetch("/api/vocabulary");
      if (wordsRes.ok) {
        const wordsData = await wordsRes.json();
        setAllWords(wordsData.words || []);
      }

      // 5. Load questions
      const testRes = await fetch("/api/tests");
      if (testRes.ok) {
        const testData = await testRes.json();
        setAllQuestions(testData.questions || []);
      }

    } catch (err) {
      console.error("Admin loader error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  // Modify User role or plan
  const handleUpgradeUser = async (userId: string, plan: string) => {
    try {
      const res = await fetch("/api/admin/users", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: "update_plan", subscriptionPlan: plan }),
      });
      if (res.ok) {
        setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, subscriptionPlan: plan } : u));
      }
    } catch (err) {
      alert("Error upgrading user.");
    }
  };

  const handleToggleBanUser = async (userId: string, currentBanned: boolean) => {
    try {
      const res = await fetch("/api/admin/users", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: "toggle_ban", banned: !currentBanned }),
      });
      if (res.ok) {
        setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, banned: !currentBanned } : u));
      }
    } catch (err) {
      alert("Error updating ban status.");
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm("Are you sure you want to delete this user? This will also wipe all their progress statistics, saved words, and payment entries!")) return;
    try {
      const res = await fetch(`/api/admin/users?id=${userId}`, { method: "DELETE" });
      if (res.ok) {
        setAllUsers(prev => prev.filter(u => u.id !== userId));
      }
    } catch (err) {
      alert("Error deleting user.");
    }
  };

  // Add Vocabulary word
  const handleAddWord = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/vocabulary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newWord),
      });

      if (res.ok) {
        const data = await res.json();
        setAllWords(prev => [data.word, ...prev]);
        setNewWord({
          word: "", translation: "", pronunciation: "", wordType: "Noun",
          example1: "", example2: "", level: "A1", category: "General"
        });
        alert("🎉 Vocabulary Word successfully added directly to database!");
      }
    } catch (err) {
      alert("Error adding word.");
    }
  };

  // Delete Vocabulary Word
  const handleDeleteWord = async (wordId: string) => {
    if (!confirm("Delete word card?")) return;
    try {
      const res = await fetch(`/api/vocabulary?id=${wordId}`, { method: "DELETE" });
      if (res.ok) {
        setAllWords(prev => prev.filter(w => w.id !== wordId));
      }
    } catch (err) {
      alert("Error deleting word.");
    }
  };

  // Add test question
  const handleAddQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/tests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newQuestion),
      });

      if (res.ok) {
        alert("🎉 Graded test question successfully added to database!");
        setNewQuestion({
          type: "multiple_choice", questionText: "", options: "Option A;Option B;Option C;Option D",
          correctAnswer: "Option A", level: "A1", category: "Vocabulary"
        });
        // Reload questions list
        const testRes = await fetch("/api/tests");
        if (testRes.ok) {
          const testData = await testRes.json();
          setAllQuestions(testData.questions || []);
        }
      }
    } catch (err) {
      alert("Error adding question.");
    }
  };

  const handleDeleteQuestion = async (qId: string) => {
    if (!confirm("Delete this test question?")) return;
    try {
      const res = await fetch(`/api/tests?id=${qId}`, { method: "DELETE" });
      if (res.ok) {
        setAllQuestions(prev => prev.filter(q => q.id !== qId));
      }
    } catch (err) {
      alert("Error deleting question.");
    }
  };

  // Save Settings
  const handleSaveSettings = async (key: string, value: string) => {
    setConfigsSuccess("");
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      if (res.ok) {
        setConfigsSuccess("System setting successfully stored server-side!");
        setTimeout(() => setConfigsSuccess(""), 3000);
      }
    } catch (err) {
      alert("Error saving settings.");
    }
  };

  // Broadcast announcement
  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    setBroadcastSuccess("");
    if (!broadcastMsg) return;

    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: broadcastMsg, target: broadcastTarget }),
      });
      if (res.ok) {
        const data = await res.json();
        setBroadcastSuccess(data.message || "Simulated broadcast emitted!");
        setBroadcastMsg("");
      }
    } catch (err) {
      alert("Error launching broadcast.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500 mx-auto" />
          <p className="text-sm text-slate-400">Verifying administrative parameters...</p>
        </div>
      </div>
    );
  }

  // Filter lists
  const filteredUsers = allUsers.filter(u => 
    u.fullName.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.email.toLowerCase().includes(userSearch.toLowerCase())
  );

  const filteredWords = allWords.filter(w => 
    w.word.toLowerCase().includes(wordSearch.toLowerCase()) ||
    w.translation.toLowerCase().includes(wordSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-7xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Admin Navigation back */}
        <div className="flex items-center justify-between">
          <Link
            href="/dashboard"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-slate-200 transition"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard Portal
          </Link>

          <span className="text-[10px] font-black text-red-500 bg-red-950/40 border border-red-900 px-3 py-1 rounded-xl flex items-center gap-1.5">
            <ShieldAlert className="h-4 w-4 shrink-0" />
            SYSTEM OPERATOR TERMINAL (v1.0.0)
          </span>
        </div>

        {/* Dynamic Admin Menu Modules Tabs */}
        <div className="bg-slate-900 rounded-2xl p-1.5 border border-slate-800 shadow-xl flex flex-wrap gap-1">
          {[
            { id: "analytics", name: "System Analytics", icon: DollarSign },
            { id: "users", name: "Users Management", icon: Users },
            { id: "vocabulary", name: "Vocabulary Base", icon: BookOpen },
            { id: "tests", name: "Tests Bank", icon: GraduationCap },
            { id: "broadcast", name: "Broadcaster Desk", icon: Megaphone },
            { id: "ai_settings", name: "AI Settings", icon: BrainCircuit },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeModule === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 min-w-[120px] flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-bold transition ${
                  isSelected
                    ? "bg-slate-800 text-white border border-slate-700 shadow-sm"
                    : "text-slate-400 hover:bg-slate-850 hover:text-slate-200"
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{tab.name}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: ANALYTICS MODULE */}
        {activeModule === "analytics" && analytics && (
          <div className="space-y-6">
            {/* Core Counts grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Total Users</span>
                <span className="text-2xl font-black text-white mt-1 block">{analytics.totalUsers}</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Active Streakers</span>
                <span className="text-2xl font-black text-green-500 mt-1 block">{analytics.activeUsers}</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Premium Users</span>
                <span className="text-2xl font-black text-yellow-400 mt-1 block">{analytics.premiumUsers}</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Words Count</span>
                <span className="text-2xl font-black text-blue-400 mt-1 block">{analytics.wordsCount}</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Words Learned</span>
                <span className="text-2xl font-black text-cyan-400 mt-1 block">{analytics.wordsLearned}</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl text-center">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Estimated Revenue</span>
                <span className="text-2xl font-black text-emerald-500 mt-1 block">${analytics.revenue}</span>
              </div>

            </div>

            {/* Audit log of mock payments */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Payment Transaction Audit Trail</h3>
              {allPayments.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-6">No premium billing logs currently present.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-500 font-bold uppercase">
                        <th className="py-2.5">User ID</th>
                        <th className="py-2.5">Paid Tier</th>
                        <th className="py-2.5">Amount (USD)</th>
                        <th className="py-2.5">Gateway Status</th>
                        <th className="py-2.5">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/40 text-slate-300 font-medium">
                      {allPayments.map((p: any) => (
                        <tr key={p.id}>
                          <td className="py-3 font-mono text-[11px] text-slate-400">{p.userId}</td>
                          <td className="py-3 font-bold text-slate-100">{p.plan} Plan</td>
                          <td className="py-3 text-green-500">${p.amount / 100}</td>
                          <td className="py-3"><span className="bg-green-950/40 text-green-400 border border-green-900 px-2 py-0.5 rounded-sm">{p.status}</span></td>
                          <td className="py-3 text-slate-500">{new Date(p.createdAt).toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: USERS CONTROL MODULE */}
        {activeModule === "users" && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">User Directory & Bans Manager</h3>
              
              <div className="relative w-full sm:w-64 shrink-0">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search user email/names..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 bg-slate-950 outline-none focus:border-slate-700 transition"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 font-bold uppercase">
                    <th className="py-2.5">Name</th>
                    <th className="py-2.5">Role</th>
                    <th className="py-2.5">Tier Plan</th>
                    <th className="py-2.5">Banned Status</th>
                    <th className="py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300 font-medium">
                  {filteredUsers.map((item: any) => (
                    <tr key={item.id} className={item.banned ? "opacity-50" : ""}>
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <img
                            src={item.avatarUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${item.username}`}
                            className="h-7 w-7 rounded-lg bg-slate-850 shrink-0"
                            alt="Avatar"
                          />
                          <div>
                            <span className="block font-bold text-white leading-tight">{item.fullName}</span>
                            <span className="text-[10px] text-slate-500 block">@{item.username} • {item.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 capitalize font-bold text-slate-400">{item.role}</td>
                      <td className="py-3 text-slate-100">
                        <select
                          value={item.subscriptionPlan}
                          onChange={(e) => handleUpgradeUser(item.id, e.target.value)}
                          className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-white focus:outline-none"
                        >
                          <option value="Free">Free</option>
                          <option value="Basic">Basic</option>
                          <option value="IELTS">IELTS</option>
                        </select>
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded-sm font-bold text-[10px] ${
                          item.banned 
                            ? "bg-red-950/40 text-red-500 border border-red-900" 
                            : "bg-green-950/40 text-green-500 border border-green-900"
                        }`}>
                          {item.banned ? "BANNED" : "Active"}
                        </span>
                      </td>
                      <td className="py-3 text-right space-x-2">
                        <button
                          onClick={() => handleToggleBanUser(item.id, item.banned)}
                          className={`px-2 py-1 rounded-lg text-[11px] font-bold border transition ${
                            item.banned 
                              ? "bg-green-950/20 text-green-400 border-green-900 hover:bg-green-950/40" 
                              : "bg-amber-950/20 text-amber-500 border-amber-900 hover:bg-amber-950/40"
                          }`}
                        >
                          {item.banned ? "Unban" : "Ban"}
                        </button>

                        <button
                          onClick={() => handleDeleteUser(item.id)}
                          className="bg-red-950/20 text-red-400 border border-red-900 px-2 py-1 rounded-lg text-[11px] font-bold hover:bg-red-950/40 transition"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: VOCABULARY DESK */}
        {activeModule === "vocabulary" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Add word form */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2 flex items-center gap-2">
                <Plus className="h-5 w-5 text-blue-500" />
                Add Vocabulary Card
              </h3>

              <form onSubmit={handleAddWord} className="space-y-4 text-xs text-slate-300">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 mb-1 font-bold">Word</label>
                    <input
                      type="text"
                      placeholder="e.g. Ubiquitous"
                      value={newWord.word}
                      onChange={(e) => setNewWord(prev => ({...prev, word: e.target.value}))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1 font-bold">Word Type</label>
                    <input
                      type="text"
                      placeholder="e.g. Adjective"
                      value={newWord.wordType}
                      onChange={(e) => setNewWord(prev => ({...prev, wordType: e.target.value}))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold">Translation (Russian / meaning)</label>
                  <input
                    type="text"
                    placeholder="Вездесущий"
                    value={newWord.translation}
                    onChange={(e) => setNewWord(prev => ({...prev, translation: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 mb-1 font-bold">Pronunciation (IPA)</label>
                    <input
                      type="text"
                      placeholder="/juːˈbɪk.wɪ.təs/"
                      value={newWord.pronunciation}
                      onChange={(e) => setNewWord(prev => ({...prev, pronunciation: e.target.value}))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1 font-bold">Level Difficulty</label>
                    <select
                      value={newWord.level}
                      onChange={(e) => setNewWord(prev => ({...prev, level: e.target.value}))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                    >
                      {["A1", "A2", "B1", "B2", "C1", "C2", "IELTS"].map(lvl => (
                        <option key={lvl} value={lvl}>{lvl}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold">Category</label>
                  <select
                    value={newWord.category}
                    onChange={(e) => setNewWord(prev => ({...prev, category: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                  >
                    {["General", "Social", "Family", "Travel", "Academic", "Business"].map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold">Context Example 1</label>
                  <input
                    type="text"
                    placeholder="Smartphones have become ubiquitous in modern society."
                    value={newWord.example1}
                    onChange={(e) => setNewWord(prev => ({...prev, example1: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold">Context Example 2</label>
                  <input
                    type="text"
                    placeholder="The brand is ubiquitous across town."
                    value={newWord.example2}
                    onChange={(e) => setNewWord(prev => ({...prev, example2: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-blue-600 transition"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition"
                >
                  Write Word Card to DB
                </button>
              </form>
            </div>

            {/* Right: List vocabulary & search */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:col-span-2 space-y-4 flex flex-col h-[580px] overflow-hidden">
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Vocabulary Database</h3>
                <div className="relative w-48 sm:w-64">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Search database vocabulary..."
                    value={wordSearch}
                    onChange={(e) => setWordSearch(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 bg-slate-950 outline-none focus:border-slate-700 transition"
                  />
                </div>
              </div>

              <div className="overflow-y-auto flex-1 divide-y divide-slate-800/50 pr-1">
                {filteredWords.map((item: any) => (
                  <div key={item.id} className="py-3 flex items-center justify-between text-xs gap-4">
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <strong className="text-white text-sm font-bold">{item.word}</strong>
                        <span className="bg-slate-800 text-slate-400 text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase">{item.level}</span>
                        <span className="italic text-slate-500">{item.wordType}</span>
                      </div>
                      <p className="text-blue-400 font-semibold mt-0.5">{item.translation}</p>
                    </div>

                    <button
                      onClick={() => handleDeleteWord(item.id)}
                      className="text-red-400 hover:bg-red-950/40 p-2 rounded-lg transition"
                      title="Delete card"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: TESTS QUESTIONS MODULE */}
        {activeModule === "tests" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Add question */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2 flex items-center gap-2">
                <Plus className="h-5 w-5 text-green-500" />
                Add Test Question Card
              </h3>

              <form onSubmit={handleAddQuestion} className="space-y-4 text-xs text-slate-300">
                <div>
                  <label className="block text-slate-400 mb-1 font-bold">Question Type</label>
                  <select
                    value={newQuestion.type}
                    onChange={(e) => setNewQuestion(prev => ({...prev, type: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-green-600 transition"
                  >
                    <option value="multiple_choice">Multiple Choice</option>
                    <option value="translation">Translation Drill</option>
                    <option value="fill_in_the_blank">Fill In The Blank</option>
                    <option value="write_in_english">Write In English</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold font-bold">Question Text</label>
                  <textarea
                    placeholder="e.g. What is the English translation of 'Книга'?"
                    value={newQuestion.questionText}
                    onChange={(e) => setNewQuestion(prev => ({...prev, questionText: e.target.value}))}
                    className="w-full min-h-[70px] rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-green-600 transition"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold font-bold">Options (Semicolon ';' separated)</label>
                  <input
                    type="text"
                    placeholder="Water;Book;Pen;Apple"
                    value={newQuestion.options}
                    onChange={(e) => setNewQuestion(prev => ({...prev, options: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-green-600 transition"
                    required
                  />
                  <p className="text-[9px] text-slate-500 mt-0.5">Use lowercase singular string for 'write_in_english' type</p>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold font-bold">Correct Answer</label>
                  <input
                    type="text"
                    placeholder="Book"
                    value={newQuestion.correctAnswer}
                    onChange={(e) => setNewQuestion(prev => ({...prev, correctAnswer: e.target.value}))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-green-600 transition"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 mb-1 font-bold">Level Difficulty</label>
                    <select
                      value={newQuestion.level}
                      onChange={(e) => setNewQuestion(prev => ({...prev, level: e.target.value}))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-green-600 transition"
                    >
                      {["A1", "A2", "B1", "B2", "C1", "C2", "IELTS"].map(lvl => (
                        <option key={lvl} value={lvl}>{lvl}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1 font-bold">Category</label>
                    <select
                      value={newQuestion.category}
                      onChange={(e) => setNewQuestion(prev => ({...prev, category: e.target.value}))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white outline-none focus:border-green-600 transition"
                    >
                      <option value="Vocabulary">Vocabulary</option>
                      <option value="Grammar">Grammar</option>
                      <option value="Academic">Academic</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold transition"
                >
                  Write Graded Question to DB
                </button>
              </form>
            </div>

            {/* Right: List questions */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:col-span-2 space-y-4 flex flex-col h-[580px] overflow-y-auto">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Test Questions Database ({allQuestions.length})</h3>
              
              <div className="divide-y divide-slate-800/50 space-y-4 pr-1">
                {allQuestions.map((q: any) => (
                  <div key={q.id} className="pt-3 flex items-start justify-between text-xs gap-4">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="bg-green-950/40 text-green-400 border border-green-900 text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase">{q.type.replace("_", " ")}</span>
                        <span className="bg-slate-800 text-slate-400 text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase">{q.level}</span>
                      </div>
                      <p className="text-slate-100 font-bold">{q.questionText}</p>
                      <p className="text-slate-500 text-[10px]">Options: <span className="text-slate-400 italic">{q.options}</span></p>
                      <p className="text-green-500 font-bold text-[10px]">Correct: {q.correctAnswer}</p>
                    </div>

                    <button
                      onClick={() => handleDeleteQuestion(q.id)}
                      className="text-red-400 hover:bg-red-950/40 p-2 rounded-lg transition mt-1"
                      title="Delete question"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: BROADCASTER MODULE */}
        {activeModule === "broadcast" && (
          <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-5 shadow-xl">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Megaphone className="h-5 w-5 text-purple-500" />
                Push System Announcement Broadcast
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Operator can dispatch a simulated system notification to target student levels, communicating platform updates, events, or subscription alerts.
              </p>
            </div>

            <form onSubmit={handleSendBroadcast} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-400 mb-1">Target Subscriber Tier</label>
                <select
                  value={broadcastTarget}
                  onChange={(e) => setBroadcastTarget(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-4 py-2.5 text-white outline-none"
                >
                  <option value="all">All Registered Students</option>
                  <option value="Free">Free Tier Students Only</option>
                  <option value="Basic">Basic Tier Students Only</option>
                  <option value="IELTS">IELTS Master Students Only</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Announcement Body Message</label>
                <textarea
                  value={broadcastMsg}
                  onChange={(e) => setBroadcastMsg(e.target.value)}
                  placeholder="e.g. System upgrade complete! New IELTS Speaking practice cues have been injected into the IELTS module..."
                  className="w-full min-h-[120px] rounded-xl bg-slate-950 border border-slate-800 p-4 text-white outline-none focus:border-purple-600 transition"
                  required
                />
              </div>

              {broadcastSuccess && (
                <div className="p-3 bg-purple-950/40 text-purple-400 border border-purple-900 rounded-xl font-bold animate-in fade-in duration-200">
                  ✨ {broadcastSuccess}
                </div>
              )}

              <button
                type="submit"
                className="w-full rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 shadow-md shadow-purple-950"
              >
                Send Graded Broadcast Notice
              </button>
            </form>
          </div>
        )}

        {/* TAB 6: AI SETTINGS MODULE */}
        {activeModule === "ai_settings" && (
          <div className="max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl text-xs text-slate-300">
            
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <BrainCircuit className="h-5 w-5 text-cyan-500" />
                AI Mentor Settings & Model Options
              </h3>
              <p className="text-slate-500 leading-relaxed text-[11px]">
                Fine-tune the custom instruction prompt injected into the AI Mentor stream, select primary model paths, and verify access parameters.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block font-bold text-slate-400 mb-1">System Access Code (Hidden verification entry)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={adminCodeSetting}
                    onChange={(e) => setAdminCodeSetting(e.target.value)}
                    className="flex-1 rounded-xl bg-slate-950 border border-slate-800 px-4 py-2.5 text-white outline-none"
                    required
                  />
                  <button
                    onClick={() => handleSaveSettings("admin_access_code", adminCodeSetting)}
                    className="rounded-xl bg-slate-800 hover:bg-slate-700 px-4 py-2.5 text-white font-bold border border-slate-700 transition"
                  >
                    Save Code
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">AI System Prompt instructions</label>
                <textarea
                  value={aiPromptSetting}
                  onChange={(e) => setAiPromptSetting(e.target.value)}
                  className="w-full min-h-[140px] rounded-xl bg-slate-950 border border-slate-800 p-4 text-white outline-none"
                  required
                />
                <button
                  onClick={() => handleSaveSettings("ai_prompt", aiPromptSetting)}
                  className="mt-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 px-4 py-2 text-white font-bold transition block ml-auto"
                >
                  Update Instruction Prompt
                </button>
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">AI Model Path Target</label>
                <div className="flex gap-2">
                  <select
                    value={aiModelSetting}
                    onChange={(e) => setAiModelSetting(e.target.value)}
                    className="flex-1 rounded-xl bg-slate-950 border border-slate-800 px-4 py-2.5 text-white outline-none"
                  >
                    <option value="gpt-4o-mini">gpt-4o-mini (Primary choice)</option>
                    <option value="gpt-4o">gpt-4o (High-grade complexity)</option>
                    <option value="o1-mini">o1-mini (Specialist reasoning)</option>
                  </select>
                  <button
                    onClick={() => handleSaveSettings("ai_model", aiModelSetting)}
                    className="rounded-xl bg-slate-800 hover:bg-slate-700 px-4 py-2.5 text-white font-bold border border-slate-700 transition font-bold"
                  >
                    Save Model
                  </button>
                </div>
              </div>

              {configsSuccess && (
                <div className="p-3 bg-green-950/40 text-green-400 border border-green-950 rounded-xl font-bold text-center animate-in fade-in duration-200">
                  ✨ {configsSuccess}
                </div>
              )}
            </div>

          </div>
        )}

      </main>
    </div>
  );
}
