"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  BarChart2, Zap, Heart, CheckCircle2, GraduationCap, Calendar, 
  ChevronRight, Award, Trophy, Loader2, Sparkles 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function StatisticsPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/profile/statistics");
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      } else {
        router.push("/login");
      }
    } catch (err) {
      console.error("Error loading statistics:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
          <p className="text-sm text-slate-500">Formulating your learning metrics...</p>
        </div>
      </div>
    );
  }

  // Fallback defaults if no statistics yet
  const learnedCount = stats?.learnedCount || 0;
  const savedCount = stats?.savedCount || 0;
  const testsCount = stats?.testsCount || 0;
  const streak = stats?.streak || 0;
  const avgAccuracy = stats?.avgAccuracy || 0;
  const history = stats?.history || [];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-5xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Module Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <BarChart2 className="h-6 w-6 text-blue-600" />
              Your Progress & Learning Analytics
            </h1>
            <p className="text-slate-500 text-xs mt-1">
              Analyze your performance tenses, vocabulary counts, and average exam success rates.
            </p>
          </div>
        </div>

        {/* Core Stats Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs text-center flex flex-col justify-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Learned Words</span>
            <span className="text-2xl font-black text-slate-900 block mt-1">{learnedCount}</span>
            <span className="text-[10px] text-green-500 mt-1 block">In vocabulary list</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs text-center flex flex-col justify-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Saved Words</span>
            <span className="text-2xl font-black text-slate-900 block mt-1">{savedCount}</span>
            <span className="text-[10px] text-rose-500 mt-1 block">Quick repeat cards</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs text-center flex flex-col justify-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Tests Taken</span>
            <span className="text-2xl font-black text-slate-900 block mt-1">{testsCount}</span>
            <span className="text-[10px] text-indigo-500 mt-1 block">Graded modules</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs text-center flex flex-col justify-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Current Streak</span>
            <span className="text-2xl font-black text-amber-500 block mt-1 flex items-center justify-center gap-1">
              <Zap className="h-5 w-5 fill-amber-500 text-amber-500 shrink-0" />
              {streak}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block">Consecutive days</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs text-center flex flex-col justify-center col-span-2 lg:col-span-1">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Accuracy Rate</span>
            <span className="text-2xl font-black text-blue-600 block mt-1">{avgAccuracy}%</span>
            <span className="text-[10px] text-blue-500 mt-1 block">Average score</span>
          </div>

        </div>

        {/* Progress Charts & Performance Analytics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Custom SVG Performance Chart Card */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs md:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Quiz Accuracy Trends</h3>
                <p className="text-slate-400 text-[11px]">Score history of your last 6 tests taken</p>
              </div>
              <span className="bg-blue-50 text-blue-600 font-bold text-[10px] px-2.5 py-1 rounded-lg">
                Interactive Chart
              </span>
            </div>

            {/* Custom SVG Chart render */}
            <div className="h-48 w-full bg-slate-50 rounded-2xl p-4 flex flex-col justify-between border border-slate-100">
              {history.length === 0 ? (
                <div className="h-full flex items-center justify-center text-center p-4">
                  <p className="text-xs text-slate-400">Complete tests to visualize your progress trajectory over time!</p>
                </div>
              ) : (
                <>
                  {/* Chart plot representation */}
                  <div className="h-32 flex items-end justify-between px-2 gap-4">
                    {history.slice(0, 6).reverse().map((item: any, idx: number) => {
                      const scoreHeight = Math.max(10, item.score); // minimum height of 10%
                      return (
                        <div key={item.id || idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                          {/* Tooltip on hover */}
                          <div className="absolute bottom-full mb-1 bg-slate-900 text-white text-[10px] px-2 py-0.5 rounded-sm opacity-0 group-hover:opacity-100 transition duration-150 shrink-0">
                            {item.score}%
                          </div>

                          {/* Bar filled element */}
                          <div 
                            className="w-full rounded-t-lg bg-blue-600 group-hover:bg-blue-700 shadow-2xs transition-all duration-300"
                            style={{ height: `${scoreHeight}%` }}
                          />

                          {/* Level indicator label */}
                          <span className="text-[9px] font-bold text-slate-400 block mt-1">
                            {item.level} ({item.testType.charAt(0).toUpperCase()})
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="border-t border-slate-200 pt-2 flex justify-between text-[10px] text-slate-400 font-medium">
                    <span>Older attempts</span>
                    <span>Most recent test</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Quick recommendations box */}
          <div className="rounded-3xl border border-slate-200 bg-slate-900 text-white p-6 shadow-md flex flex-col justify-between">
            <div className="space-y-4">
              <div className="inline-flex rounded-xl bg-white/10 p-2.5">
                <Trophy className="h-5 w-5 text-yellow-300 fill-yellow-300" />
              </div>
              <h3 className="text-sm font-bold">Personalized Advice</h3>
              
              <div className="space-y-3 text-xs leading-relaxed text-slate-300 font-medium">
                <p>
                  🚀 {learnedCount < 5 
                    ? "Start by browsing A1 Vocabulary Cards. Marking 5 words as learned strengthens memory retention."
                    : "Excellent base. We suggest taking a B1 Translation Drill test to benchmark your contextual skills!"}
                </p>
                <p>
                  🔥 {streak > 0 
                    ? `Great job on keeping a ${streak} day streak! Maintain it tomorrow to unlock exclusive custom achievements!` 
                    : "No streak active. Spend 5 minutes on the platform today to ignite your vocabulary streak!"}
                </p>
              </div>
            </div>

            <Link
              href="/dashboard"
              className="mt-6 w-full text-center rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white hover:bg-blue-700 transition"
            >
              Continue Learning
            </Link>
          </div>

        </div>

        {/* Graded Test History Listing */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-950">Test Attempt History</h3>
            <span className="text-[11px] text-slate-400 font-semibold">{history.length} attempts total</span>
          </div>

          {history.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-xs text-slate-400">You haven't taken any graded tests yet.</p>
              <Link href="/tests" className="mt-2 text-xs font-bold text-blue-600 hover:underline inline-block">
                Start your first test now
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 uppercase font-bold tracking-wider">
                    <th className="py-2.5 font-bold">Level</th>
                    <th className="py-2.5 font-bold">Test Type</th>
                    <th className="py-2.5 font-bold">Correct / Total</th>
                    <th className="py-2.5 font-bold">Accuracy</th>
                    <th className="py-2.5 font-bold">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 font-medium text-slate-700">
                  {history.map((item: any) => {
                    const dateStr = item.createdAt 
                      ? new Date(item.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
                      : "Recently";

                    return (
                      <tr key={item.id}>
                        <td className="py-3 font-bold text-slate-900">
                          <span className="bg-slate-100 px-2 py-0.5 rounded-sm">
                            {item.level}
                          </span>
                        </td>
                        <td className="py-3 capitalize">
                          {item.testType.replace("_", " ")}
                        </td>
                        <td className="py-3">
                          {item.correctAnswers} / {item.totalQuestions}
                        </td>
                        <td className="py-3">
                          <span className={`font-bold px-1.5 py-0.5 rounded-sm ${
                            item.accuracy >= 80 
                              ? "bg-green-50 text-green-700" 
                              : item.accuracy >= 50 
                              ? "bg-amber-50 text-amber-700" 
                              : "bg-red-50 text-red-700"
                          }`}>
                            {item.accuracy}%
                          </span>
                        </td>
                        <td className="py-3 text-slate-400">
                          {dateStr}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </main>
    </div>
  );
}
