"use"

"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  BrainCircuit, Send, Star, Lock, Award, ShieldAlert, Sparkles, 
  HelpCircle, RefreshCw, Info, User, Loader2 
} from "lucide-react";
import Navbar from "@/components/Navbar";

interface Message {
  id: string;
  sender: "user" | "mentor";
  text: string;
  timestamp: Date;
}

const PRESET_TOPICS = [
  { label: "📘 Grammar Help", prompt: "Explain the difference between Present Perfect and Past Simple tenses with examples.", category: "Grammar" },
  { label: "🏆 IELTS Writing Task 2", prompt: "What is the best 4-paragraph structure to write a Band 7 opinion essay?", category: "IELTS" },
  { label: "📚 Vocabulary Drill", prompt: "Give me 5 advanced IELTS synonyms for common words like 'big', 'solve', and 'bad' with example sentences.", category: "Vocabulary" },
  { label: "🗣️ Speaking Practice", prompt: "What is the PPF (Past, Present, Future) strategy for IELTS Speaking Part 2 cue cards?", category: "Speaking" }
];

export default function MentorPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [sending, setSending] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const router = useRouter();

  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        
        // Add initial system greeting
        setMessages([
          {
            id: "msg_init",
            sender: "mentor",
            text: `### 👋 Welcome to your private LinguaGoWords AI Mentor space!

I am your personal English Language Tutor. I am trained to evaluate your writing, solve complex grammar doubts, suggest high-level IELTS vocabulary, and formulate speaking strategies.

*How can I help you accelerate your English fluency goals today? Click one of the quick-prompt tags below or type your custom question!*`,
            timestamp: new Date()
          }
        ]);
      } else {
        router.push("/login");
      }
    } catch {
      router.push("/login");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  useEffect(() => {
    // Scroll to bottom of chat
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (textToSend: string, category: string = "General") => {
    if (!textToSend.trim() || sending) return;

    // Add user message
    const userMsgId = "msg_u_" + Math.random().toString(36).substring(2, 9);
    const userMsg: Message = {
      id: userMsgId,
      sender: "user",
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue("");
    setSending(true);

    try {
      const res = await fetch("/api/mentor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: textToSend, category }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        const mentorMsgId = "msg_m_" + Math.random().toString(36).substring(2, 9);
        setMessages(prev => [...prev, {
          id: mentorMsgId,
          sender: "mentor",
          text: data.response,
          timestamp: new Date()
        }]);
      } else {
        // Show error message
        const errId = "msg_err_" + Math.random().toString(36).substring(2, 9);
        setMessages(prev => [...prev, {
          id: errId,
          sender: "mentor",
          text: `⚠️ **System notice:** ${data.error || "The AI Mentor was unable to process your request. Please try again."}`,
          timestamp: new Date()
        }]);
      }
    } catch (err) {
      console.error("AI chat error:", err);
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
          <p className="text-sm text-slate-500">Connecting to AI Mentor channel...</p>
        </div>
      </div>
    );
  }

  const isFreePlan = user?.subscriptionPlan === "Free";

  // Restricted Access Screen
  if (isFreePlan) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
        <Navbar />
        <main className="mx-auto max-w-3xl w-full px-4 sm:px-6 lg:px-8 mt-12">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 sm:p-12 text-center shadow-md space-y-6">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-50 text-cyan-600 border border-cyan-100">
              <BrainCircuit className="h-8 w-8 animate-pulse" />
            </div>

            <div className="space-y-2 max-w-lg mx-auto">
              <h2 className="text-2xl font-black text-slate-950">AI Language Mentor (24/7 Support)</h2>
              <p className="text-sm text-slate-500 leading-relaxed">
                Unlock a private conversation room with our English Language Mentor. Get real-time grammar checks, sentence restructuring guidance, and exam preparation feedback.
              </p>
            </div>

            <div className="rounded-2xl border border-blue-100 bg-blue-50/40 p-4 text-xs text-blue-800 font-medium max-w-md mx-auto text-left">
              🔒 AI Mentor is a **Premium** capability. Users on the **Free** tier do not have access. Please consider upgrading to Basic or IELTS plan to unleash full conversational learning!
            </div>

            <div className="pt-2">
              <Link
                href="/premium"
                className="inline-flex items-center gap-1.5 rounded-xl bg-blue-600 px-6 py-3.5 text-xs font-bold text-white shadow-md shadow-blue-200 hover:bg-blue-700 transition"
              >
                <Star className="h-4 w-4 text-yellow-300" />
                Unlock AI Mentor
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans h-screen">
      <Navbar />

      <main className="mx-auto max-w-6xl w-full px-4 sm:px-6 lg:px-8 flex flex-col flex-1 py-6 overflow-hidden min-h-[500px]">
        
        {/* Layout Grid */}
        <div className="flex flex-col lg:flex-row flex-1 bg-white rounded-3xl border border-slate-200 shadow-lg overflow-hidden h-full">
          
          {/* Left Column: Preset tags & guidelines */}
          <div className="w-full lg:w-80 border-b lg:border-b-0 lg:border-r border-slate-200 p-6 flex flex-col justify-between bg-slate-50/50 shrink-0">
            <div className="space-y-6">
              <div className="space-y-1">
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <BrainCircuit className="h-5 w-5 text-cyan-500 shrink-0" />
                  Your AI English Mentor
                </h2>
                <p className="text-[11px] text-slate-400 font-semibold leading-relaxed">
                  Engage in deep study dialogs. Ask grammar definitions, vocabulary synonyms, or seek composition checks.
                </p>
              </div>

              {/* Preset buttons */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Quick-Study Preset Prompts</span>
                <div className="flex flex-wrap lg:flex-col gap-2">
                  {PRESET_TOPICS.map((topic, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(topic.prompt, topic.category)}
                      disabled={sending}
                      className="text-left bg-white border border-slate-200 hover:border-blue-300 hover:bg-blue-50/20 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:text-slate-950 transition shadow-2xs flex-1 lg:flex-none"
                    >
                      {topic.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Model stats disclaimer */}
            <div className="pt-6 border-t border-slate-200/60 text-[10px] text-slate-400 space-y-1.5 hidden lg:block">
              <p className="flex items-center gap-1 font-semibold text-slate-500">
                <Info className="h-3.5 w-3.5 shrink-0" />
                Study Room Parameters
              </p>
              <p>• Model: GPT-4o-Mini Graded</p>
              <p>• Storage: Logs saved in database</p>
              <p>• Feedback: Formatted in markdown</p>
            </div>
          </div>

          {/* Right Column: Chat Box */}
          <div className="flex-1 flex flex-col justify-between overflow-hidden bg-white">
            
            {/* Thread Container */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              {messages.map((msg) => {
                const isUser = msg.sender === "user";
                return (
                  <div 
                    key={msg.id} 
                    className={`flex items-start gap-3 max-w-[85%] ${isUser ? "ml-auto flex-row-reverse" : "mr-auto"}`}
                  >
                    {/* Icon / Avatar indicator */}
                    <div className={`h-8 w-8 rounded-full shrink-0 flex items-center justify-center border text-xs font-bold ${
                      isUser 
                        ? "bg-slate-100 border-slate-200 text-slate-700" 
                        : "bg-cyan-50 border-cyan-100 text-cyan-600"
                    }`}>
                      {isUser ? <User className="h-4 w-4" /> : <BrainCircuit className="h-4 w-4 text-cyan-500" />}
                    </div>

                    {/* Speech bubble */}
                    <div className={`rounded-2xl p-4 text-xs sm:text-sm shadow-2xs border ${
                      isUser 
                        ? "bg-slate-900 border-slate-950 text-white" 
                        : "bg-slate-50 border-slate-100 text-slate-800"
                    }`}>
                      {/* Standard parsing support for custom seeded lists or returns */}
                      <div className="prose prose-xs max-w-none space-y-2">
                        {msg.text.split("\n").map((line, lIdx) => {
                          // Simple bold parser
                          let renderedLine = line;
                          const boldRegex = /\*\*(.*?)\*\*/g;
                          renderedLine = renderedLine.replace(boldRegex, "<strong>$1</strong>");
                          
                          // Simple markdown header translation
                          if (line.startsWith("### ")) {
                            return <h3 key={lIdx} className="text-sm font-bold text-blue-600 mt-2 block" dangerouslySetInnerHTML={{ __html: renderedLine.substring(4) }} />;
                          }
                          if (line.startsWith("#### ")) {
                            return <h4 key={lIdx} className="text-xs font-bold text-slate-800 mt-1 block" dangerouslySetInnerHTML={{ __html: renderedLine.substring(5) }} />;
                          }
                          if (line.startsWith("*   ")) {
                            return <li key={lIdx} className="ml-4 list-disc text-xs" dangerouslySetInnerHTML={{ __html: renderedLine.substring(4) }} />;
                          }
                          if (line.startsWith("• ")) {
                            return <li key={lIdx} className="ml-4 list-disc text-xs" dangerouslySetInnerHTML={{ __html: renderedLine.substring(2) }} />;
                          }

                          return <p key={lIdx} className="leading-relaxed" dangerouslySetInnerHTML={{ __html: renderedLine }} />;
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}

              {sending && (
                <div className="flex items-start gap-3 max-w-[85%] mr-auto">
                  <div className="h-8 w-8 rounded-full bg-cyan-50 border border-cyan-100 text-cyan-600 flex items-center justify-center">
                    <Loader2 className="h-4 w-4 animate-spin text-cyan-500" />
                  </div>
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-xs text-slate-500 italic flex items-center gap-2">
                    AI Mentor is writing a detailed grammatical analysis...
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input Form area */}
            <div className="p-4 border-t border-slate-200 bg-slate-50/50">
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage(inputValue);
                }} 
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  placeholder="Ask a grammar rule, ask synonym, write an IELTS question..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  className="flex-1 rounded-xl border border-slate-200 px-4 py-3 text-xs sm:text-sm text-slate-950 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-none transition bg-white"
                  disabled={sending}
                  required
                />
                
                <button
                  type="submit"
                  disabled={!inputValue.trim() || sending}
                  className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white p-3 transition disabled:opacity-30 flex items-center justify-center shrink-0"
                  title="Send message"
                >
                  <Send className="h-4 w-4 sm:h-5 sm:w-5" />
                </button>
              </form>
            </div>

          </div>

        </div>

      </main>
    </div>
  );
}
