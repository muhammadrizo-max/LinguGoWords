"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  GraduationCap, Play, Lock, CheckCircle2, XCircle, Award, 
  HelpCircle, Sparkles, ArrowRight, RefreshCw, BarChart2, Loader2 
} from "lucide-react";
import Navbar from "@/components/Navbar";

const TEST_TYPES = [
  { id: "multiple_choice", name: "Multiple Choice", desc: "Choose the correct translation option." },
  { id: "translation", name: "Translation Drill", desc: "Select the correct Russian meaning." },
  { id: "fill_in_the_blank", name: "Fill In The Blank", desc: "Complete sentences using key keywords." },
  { id: "write_in_english", name: "Write In English", desc: "Type the exact lowercase word translation." }
];

const LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2", "IELTS"];

export default function TestsPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Setup state
  const [selectedLevel, setSelectedLevel] = useState("A1");
  const [selectedType, setSelectedType] = useState("multiple_choice");
  const [quizStarted, setQuizStarted] = useState(false);

  // Active quiz states
  const [questions, setQuestions] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState("");
  const [typedAnswer, setTypedAnswer] = useState("");
  
  // Results tracker
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [savingResult, setSavingResult] = useState(false);

  const router = useRouter();

  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        router.push("/login");
      }
    } catch {
      router.push("/login");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  // Determine if level is locked based on subscription tier
  const isLevelLocked = (level: string) => {
    if (!user) return true;
    const plan = user.subscriptionPlan;
    if (plan === "IELTS" || user.role === "admin" || user.role === "super_admin") return false;
    
    if (plan === "Basic") {
      // Basic plan gets A1, A2, B1
      return !["A1", "A2", "B1"].includes(level);
    }
    
    // Free plan gets A1 only
    return level !== "A1";
  };

  const startQuiz = async () => {
    if (isLevelLocked(selectedLevel)) {
      alert("This level is locked on your current subscription plan.");
      return;
    }

    setQuizStarted(true);
    setQuizFinished(false);
    setCurrentIndex(0);
    setCorrectCount(0);
    setWrongCount(0);
    setSelectedAnswer("");
    setTypedAnswer("");

    try {
      // Fetch questions filtered by level
      const res = await fetch(`/api/tests?level=${selectedLevel}`);
      if (res.ok) {
        const data = await res.json();
        let fetched = data.questions || [];

        // Filter by type if applicable
        if (selectedType) {
          fetched = fetched.filter((q: any) => q.type === selectedType);
        }

        // If no questions in this specific type, use any questions for this level as fallback
        if (fetched.length === 0) {
          fetched = (data.questions || []).slice(0, 5);
        }

        // Shuffle questions or limit to 5
        setQuestions(fetched.slice(0, 5));
      }
    } catch (err) {
      console.error("Error loading quiz questions:", err);
    }
  };

  const submitAnswer = () => {
    const currentQuestion = questions[currentIndex];
    let isCorrect = false;

    if (currentQuestion.type === "write_in_english") {
      isCorrect = typedAnswer.trim().toLowerCase() === currentQuestion.correctAnswer.toLowerCase();
    } else {
      isCorrect = selectedAnswer === currentQuestion.correctAnswer;
    }

    if (isCorrect) {
      setCorrectCount(prev => prev + 1);
    } else {
      setWrongCount(prev => prev + 1);
    }

    // Move to next question or finish quiz
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer("");
      setTypedAnswer("");
    } else {
      finishQuiz(isCorrect ? correctCount + 1 : correctCount);
    }
  };

  const finishQuiz = async (finalCorrect: number) => {
    setQuizFinished(true);
    setSavingResult(true);

    const totalQuestions = questions.length;
    const finalWrong = totalQuestions - finalCorrect;
    const accuracy = totalQuestions > 0 ? Math.round((finalCorrect / totalQuestions) * 100) : 0;
    const score = accuracy; // score represents percentage accuracy

    try {
      // Post result to db
      await fetch("/api/tests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          score,
          totalQuestions,
          correctAnswers: finalCorrect,
          wrongAnswers: finalWrong,
          accuracy,
          testType: selectedType,
          level: selectedLevel,
        }),
      });
    } catch (err) {
      console.error("Failed to save test results:", err);
    } finally {
      setSavingResult(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
          <p className="text-sm text-slate-500">Checking credentials...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-4xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Module Header */}
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-blue-600" />
            Language Testing Center
          </h1>
          <p className="text-slate-500 text-xs mt-1">
            Challenge your English grammar, vocabulary translation, spelling, and listening skills with direct grading.
          </p>
        </div>

        {/* SETUP SCREEN */}
        {!quizStarted && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Step 1 & 2 controls */}
            <div className="md:col-span-2 space-y-6">
              <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">1. Select Target Level</h3>
                
                <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                  {LEVELS.map((lvl) => {
                    const locked = isLevelLocked(lvl);
                    const isSelected = selectedLevel === lvl;

                    return (
                      <button
                        key={lvl}
                        onClick={() => setSelectedLevel(lvl)}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition ${
                          isSelected
                            ? "bg-blue-600 border-blue-600 text-white shadow-xs"
                            : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                        }`}
                      >
                        <span className="text-sm">{lvl}</span>
                        {locked && <Lock className="h-3 w-3 text-slate-400 mt-1 shrink-0" />}
                      </button>
                    );
                  })}
                </div>

                {isLevelLocked(selectedLevel) && (
                  <div className="rounded-xl bg-amber-50 border border-amber-100 p-3 text-xs text-amber-700 font-medium">
                    🔒 Level <strong>{selectedLevel}</strong> is locked. Access to this level is a premium feature. Please consider upgrading to unlock.
                  </div>
                )}
              </div>

              {/* Quiz type selector */}
              <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">2. Select Test Type</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {TEST_TYPES.map((type) => {
                    const isSelected = selectedType === type.id;
                    return (
                      <button
                        key={type.id}
                        onClick={() => setSelectedType(type.id)}
                        className={`text-left p-4 rounded-2xl border transition flex flex-col justify-between ${
                          isSelected
                            ? "border-blue-600 bg-blue-50/50"
                            : "border-slate-200 bg-slate-50/50 hover:bg-slate-100"
                        }`}
                      >
                        <span className={`text-sm font-bold ${isSelected ? "text-blue-600" : "text-slate-800"}`}>
                          {type.name}
                        </span>
                        <span className="text-xs text-slate-500 mt-1">
                          {type.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Start Button Panel */}
            <div className="rounded-3xl border border-slate-200 bg-slate-900 text-white p-6 shadow-xl flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="inline-flex rounded-xl bg-white/10 p-3">
                  <Play className="h-6 w-6 text-yellow-300 fill-yellow-300" />
                </div>
                <h3 className="text-lg font-bold">Ready to Start?</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Your progress will be tracked instantly. Complete the questions to update your stats, streaks, and English fluency records.
                </p>

                <div className="pt-2 border-t border-white/10 text-xs text-slate-400 space-y-1">
                  <p>• 5 Questions per test</p>
                  <p>• Immediate feedback</p>
                  <p>• Saves score to Drizzle DB</p>
                </div>
              </div>

              <button
                onClick={startQuiz}
                disabled={isLevelLocked(selectedLevel)}
                className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-3.5 text-xs font-bold text-white shadow-md hover:bg-blue-700 transition disabled:opacity-30 disabled:cursor-not-allowed"
              >
                Launch Test Module
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>

          </div>
        )}

        {/* ACTIVE QUIZ EXAM SCREEN */}
        {quizStarted && !quizFinished && (
          <div className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-10 shadow-lg space-y-6">
            {questions.length === 0 ? (
              <div className="text-center py-12 space-y-4">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
                <p className="text-slate-500 text-sm">Generating graded test questions...</p>
              </div>
            ) : (
              <>
                {/* Header status */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="bg-blue-600 text-white font-extrabold text-[9px] px-2 py-0.5 rounded-sm uppercase">
                      Level {selectedLevel}
                    </span>
                    <span className="bg-slate-100 text-slate-600 font-semibold text-[9px] px-2 py-0.5 rounded-sm uppercase">
                      {selectedType.replace("_", " ")}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 font-bold">
                    Question {currentIndex + 1} of {questions.length}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-600 transition-all duration-300"
                    style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
                  />
                </div>

                {/* Question Text */}
                <div className="space-y-2 py-4">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">Question</span>
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900">
                    {questions[currentIndex].questionText}
                  </h2>
                </div>

                {/* Options Panel (Multiple choice or text inputs) */}
                <div className="pt-2">
                  {questions[currentIndex].type === "write_in_english" ? (
                    /* Text input style */
                    <div className="space-y-4">
                      <input
                        type="text"
                        placeholder="Type lowercase answer in English..."
                        value={typedAnswer}
                        onChange={(e) => setTypedAnswer(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-none transition"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && typedAnswer.trim()) {
                            submitAnswer();
                          }
                        }}
                      />
                      <p className="text-[10px] text-slate-400">Press Enter key or click Submit to continue</p>
                    </div>
                  ) : (
                    /* Option buttons list */
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {questions[currentIndex].options.split(";").map((opt: string, optIdx: number) => {
                        const isSelected = selectedAnswer === opt;
                        return (
                          <button
                            key={optIdx}
                            onClick={() => setSelectedAnswer(opt)}
                            className={`text-left p-4 rounded-xl border text-sm font-semibold transition ${
                              isSelected
                                ? "bg-blue-600 text-white border-blue-600 shadow-sm"
                                : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                            }`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Bottom submit button */}
                <div className="pt-6 border-t border-slate-100 flex justify-between items-center">
                  <button
                    onClick={() => setQuizStarted(false)}
                    className="text-xs font-bold text-slate-400 hover:text-slate-600 transition"
                  >
                    Abort Quiz
                  </button>

                  <button
                    onClick={submitAnswer}
                    disabled={
                      questions[currentIndex].type === "write_in_english"
                        ? !typedAnswer.trim()
                        : !selectedAnswer
                    }
                    className="rounded-xl bg-slate-900 hover:bg-slate-800 text-white px-6 py-2.5 text-xs font-bold transition disabled:opacity-30"
                  >
                    Submit & Next
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* FINAL QUIZ METRICS / SCORE REPORT */}
        {quizStarted && quizFinished && (
          <div className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-10 shadow-lg text-center space-y-6 animate-in zoom-in-95 duration-200">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 text-blue-600">
              <Award className="h-10 w-10 text-yellow-500" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-black text-slate-900">Quiz Completed!</h2>
              <p className="text-xs text-slate-500">Your performance statistics have been recorded in the database.</p>
            </div>

            {/* Results Grid block */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-xl mx-auto py-4">
              
              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <p className="text-xs text-slate-400 font-bold uppercase">Accuracy</p>
                <h3 className="text-2xl font-black text-blue-600 mt-1">
                  {questions.length > 0 ? Math.round((correctCount / questions.length) * 100) : 0}%
                </h3>
              </div>

              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <p className="text-xs text-slate-400 font-bold uppercase">Correct</p>
                <h3 className="text-2xl font-black text-green-500 mt-1 flex items-center justify-center gap-1">
                  <CheckCircle2 className="h-5 w-5 shrink-0" />
                  {correctCount}
                </h3>
              </div>

              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <p className="text-xs text-slate-400 font-bold uppercase">Incorrect</p>
                <h3 className="text-2xl font-black text-red-500 mt-1 flex items-center justify-center gap-1">
                  <XCircle className="h-5 w-5 shrink-0" />
                  {wrongCount}
                </h3>
              </div>

              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <p className="text-xs text-slate-400 font-bold uppercase">Questions</p>
                <h3 className="text-2xl font-black text-slate-700 mt-1">{questions.length}</h3>
              </div>

            </div>

            {/* Fun encouraging quote */}
            <p className="text-sm font-semibold italic text-slate-600">
              {correctCount === questions.length 
                ? "Perfect score! Outstanding work on your language goals!"
                : correctCount >= questions.length / 2
                ? "Excellent progress! Review your wrong answers to master these definitions."
                : "Keep studying! Persistent practice is the absolute pathway to fluency."}
            </p>

            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => setQuizStarted(false)}
                className="rounded-xl border border-slate-200 px-5 py-3 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
              >
                Go Back to Setup
              </button>
              
              <button
                onClick={startQuiz}
                className="rounded-xl bg-blue-600 px-6 py-3 text-xs font-bold text-white shadow-md hover:bg-blue-700 transition"
              >
                Try Again Now
              </button>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
