"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  Star, CheckCircle2, ShieldCheck, CreditCard, Sparkles, 
  ArrowRight, Award, Zap, Heart, Loader2 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function PremiumPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [purchasingPlan, setPurchasingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const router = useRouter();

  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        router.push("/login");
      }
    } catch {
      router.push("/login");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const handlePurchase = async (plan: string) => {
    setPurchasingId(plan);
    setSuccessMsg("");
    setErrorMsg("");

    try {
      const res = await fetch("/api/premium/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setSuccessMsg(data.message || `Successfully subscribed to the ${plan} Plan!`);
        
        // Refresh local user state immediately
        await fetchUser();

        // Redirect to dashboard after a delay
        setTimeout(() => {
          router.push("/dashboard");
          router.refresh();
        }, 2000);
      } else {
        setErrorMsg(data.error || "Purchase failed. Please try again.");
      }
    } catch (err) {
      setErrorMsg("An unexpected connection error occurred.");
    } finally {
      setPurchasingId(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
          <p className="text-sm text-slate-500">Checking current billing plan...</p>
        </div>
      </div>
    );
  }

  const activePlan = user?.subscriptionPlan || "Free";

  const premiumFeaturesList = [
    { name: "Full A1 Vocabulary Cards", free: true, basic: true, ielts: true },
    { name: "All Vocabulary Categories", free: false, basic: true, ielts: true },
    { name: "A2 and B1 Level Graded Cards", free: false, basic: true, ielts: true },
    { name: "Vocabulary Save & Mark Learned tracking", free: false, basic: true, ielts: true },
    { name: "B2, C1, and C2 Advanced Vocabulary", free: false, basic: false, ielts: true },
    { name: "24/7 Premium AI Tutor & Essay Analyzer", free: false, basic: false, ielts: true },
    { name: "Specialized IELTS Reading, Writing, Listening & Speaking", free: false, basic: false, ielts: true },
    { name: "Database Test History Progress Charts", free: false, basic: false, ielts: true }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-5xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-8">
        
        {/* Module Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700 border border-blue-100">
            <Sparkles className="h-3.5 w-3.5" />
            Pricing Plans & Premium Upgrade
          </div>
          <h1 className="text-3xl font-black text-slate-950 tracking-tight sm:text-4xl">
            Choose Your Level of English Fluency
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm">
            Unlock professional grading tiers, expand vocabulary database restrictions, and engage in study chats with your personal AI Coach.
          </p>
        </div>

        {/* Global Feedback Messages */}
        {(successMsg || errorMsg) && (
          <div className="max-w-xl mx-auto animate-in fade-in zoom-in-95 duration-200">
            {successMsg && (
              <div className="bg-green-50 border border-green-200 text-green-700 p-4 rounded-2xl text-xs font-semibold text-center flex items-center justify-center gap-2">
                <ShieldCheck className="h-5 w-5 shrink-0 text-green-600" />
                {successMsg}
              </div>
            )}
            {errorMsg && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-2xl text-xs font-semibold text-center">
                ⚠️ {errorMsg}
              </div>
            )}
          </div>
        )}

        {/* Plan Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          
          {/* FREE PLAN */}
          <div className={`rounded-3xl border p-6 flex flex-col justify-between space-y-6 ${
            activePlan === "Free" 
              ? "bg-white border-blue-500 shadow-md ring-1 ring-blue-500" 
              : "bg-white border-slate-200 shadow-3xs"
          }`}>
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Free Access</h3>
                  <p className="text-[10px] text-slate-400">Excellent starting block</p>
                </div>
                {activePlan === "Free" && (
                  <span className="bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    Current Plan
                  </span>
                )}
              </div>

              <div className="text-3xl font-black text-slate-950">
                $0<span className="text-xs font-normal text-slate-400">/ forever</span>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-600">
                <p className="flex items-center gap-2">✔️ Full Access to level **A1**</p>
                <p className="flex items-center gap-2">✔️ General Category vocabulary</p>
                <p className="flex items-center gap-2">✔️ Basic Multiple Choice Tests</p>
              </div>
            </div>

            <button
              onClick={() => handlePurchase("Free")}
              disabled={purchasingPlan !== null || activePlan === "Free"}
              className={`w-full rounded-xl py-3 text-xs font-bold text-center transition ${
                activePlan === "Free"
                  ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                  : "bg-slate-200 hover:bg-slate-300 text-slate-700"
              }`}
            >
              {purchasingPlan === "Free" ? "Processing..." : activePlan === "Free" ? "Active Now" : "Downgrade to Free"}
            </button>
          </div>

          {/* BASIC PREMIUM */}
          <div className={`rounded-3xl border-2 p-6 flex flex-col justify-between space-y-6 relative ${
            activePlan === "Basic" 
              ? "bg-white border-blue-600 shadow-lg ring-1 ring-blue-600" 
              : "bg-white border-slate-200 shadow-md"
          }`}>
            {activePlan !== "Basic" && activePlan !== "IELTS" && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-blue-600 px-3 py-0.5 text-[9px] font-extrabold text-white uppercase tracking-wider">
                Recommended
              </div>
            )}
            
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Basic Premium</h3>
                  <p className="text-[10px] text-slate-400">Accelerated common fluency</p>
                </div>
                {activePlan === "Basic" && (
                  <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    Current Plan
                  </span>
                )}
              </div>

              <div className="text-3xl font-black text-slate-950">
                $9.99<span className="text-xs font-normal text-slate-400">/ year</span>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-600">
                <p className="flex items-center gap-2">✔️ Unlock levels **A1, A2, and B1**</p>
                <p className="flex items-center gap-2">✔️ All Vocabulary Categories</p>
                <p className="flex items-center gap-2">✔️ Saved Words & review drills</p>
                <p className="flex items-center gap-2">✔️ Core Graded Multiple Choice Tests</p>
              </div>
            </div>

            <button
              onClick={() => handlePurchase("Basic")}
              disabled={purchasingPlan !== null || activePlan === "Basic"}
              className={`w-full rounded-xl py-3 text-xs font-bold text-center transition ${
                activePlan === "Basic"
                  ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                  : "bg-blue-600 hover:bg-blue-700 text-white shadow-xs"
              }`}
            >
              {purchasingPlan === "Basic" ? "Processing..." : activePlan === "Basic" ? "Active Now" : "Subscribe Basic"}
            </button>
          </div>

          {/* IELTS MASTER */}
          <div className={`rounded-3xl border p-6 flex flex-col justify-between space-y-6 ${
            activePlan === "IELTS" 
              ? "bg-white border-purple-500 shadow-md ring-1 ring-purple-500" 
              : "bg-white border-slate-200 shadow-3xs"
          }`}>
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-base font-bold text-slate-950">IELTS Master</h3>
                  <p className="text-[10px] text-slate-400">Total language dominance</p>
                </div>
                {activePlan === "IELTS" && (
                  <span className="bg-purple-100 text-purple-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    Current Plan
                  </span>
                )}
              </div>

              <div className="text-3xl font-black text-slate-950">
                $24.99<span className="text-xs font-normal text-slate-400">/ year</span>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-600">
                <p className="flex items-center gap-2">✔️ **All Levels** unlocked (A1 to IELTS)</p>
                <p className="flex items-center gap-2">✔️ **24/7 AI Mentor** Chat unlocked</p>
                <p className="flex items-center gap-2">✔️ **IELTS Modules** (Reading/Writing/Speaking)</p>
                <p className="flex items-center gap-2">✔️ Real-time accuracy metrics</p>
              </div>
            </div>

            <button
              onClick={() => handlePurchase("IELTS")}
              disabled={purchasingPlan !== null || activePlan === "IELTS"}
              className={`w-full rounded-xl py-3 text-xs font-bold text-center transition ${
                activePlan === "IELTS"
                  ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                  : "bg-slate-900 hover:bg-slate-800 text-white"
              }`}
            >
              {purchasingPlan === "IELTS" ? "Processing..." : activePlan === "IELTS" ? "Active Now" : "Subscribe IELTS Pro"}
            </button>
          </div>

        </div>

        {/* Feature comparison table */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs max-w-4xl mx-auto space-y-4">
          <h3 className="text-sm font-bold text-slate-950">Detailed Plan Comparison</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-bold uppercase">
                  <th className="py-2">Features</th>
                  <th className="py-2 text-center">Free</th>
                  <th className="py-2 text-center">Basic</th>
                  <th className="py-2 text-center">IELTS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 font-semibold text-slate-700">
                {premiumFeaturesList.map((feat, i) => (
                  <tr key={i}>
                    <td className="py-3 text-slate-800">{feat.name}</td>
                    <td className="py-3 text-center">{feat.free ? "✔️" : "❌"}</td>
                    <td className="py-3 text-center">{feat.basic ? "✔️" : "❌"}</td>
                    <td className="py-3 text-center">{feat.ielts ? "✔️" : "❌"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </main>
    </div>
  );
}
