"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  Heart, Search, Trash2, Volume2, BookOpen, GraduationCap, 
  HelpCircle, Eye, ArrowRight, Play, X, CheckCircle 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function SavedWordsPage() {
  const [user, setUser] = useState<any>(null);
  const [savedItems, setSavedItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Review Study Mode state
  const [reviewMode, setReviewMode] = useState(false);
  const [reviewIndex, setReviewIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);

  const router = useRouter();

  const fetchUserAndSaved = async () => {
    try {
      const uRes = await fetch("/api/auth/me");
      if (!uRes.ok) {
        router.push("/login");
        return;
      }
      const uData = await uRes.json();
      setUser(uData.user);

      // Now fetch all words, which filters locally for saved words
      const vRes = await fetch("/api/vocabulary");
      if (vRes.ok) {
        const vData = await vRes.json();
        // filter vocabulary that have isSaved = true
        const saved = (vData.words || []).filter((w: any) => w.isSaved);
        setSavedItems(saved);
      }
    } catch (err) {
      console.error("Error loading saved words:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserAndSaved();
  }, []);

  const handleRemove = async (wordId: string) => {
    try {
      const res = await fetch("/api/vocabulary/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wordId, action: "unsave" }),
      });

      if (res.ok) {
        // Remove from local list
        setSavedItems(prev => prev.filter(item => item.id !== wordId));
        // adjust review index if needed
        if (reviewIndex >= savedItems.length - 1) {
          setReviewIndex(Math.max(0, savedItems.length - 2));
        }
      }
    } catch (err) {
      console.error("Error removing word:", err);
    }
  };

  const speakWord = (text: string) => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "en-US";
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  const filteredItems = savedItems.filter(item => 
    item.word.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.translation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Review flashcard states
  const activeReviewItem = savedItems[reviewIndex];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-4xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
              <Heart className="h-6 w-6 text-rose-500 fill-rose-500" />
              Saved Vocabulary List
            </h1>
            <p className="text-slate-500 text-xs mt-1">
              Organize, search, pronounce, and study vocabulary cards saved during your lessons.
            </p>
          </div>

          {/* Quick Review trigger */}
          {savedItems.length > 0 && !reviewMode && (
            <button
              onClick={() => {
                setReviewMode(true);
                setReviewIndex(0);
                setShowAnswer(false);
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-3 text-xs font-bold text-white shadow-md shadow-blue-200 hover:bg-blue-700 transition self-start sm:self-auto"
            >
              <Play className="h-4 w-4 fill-white" />
              Start Review Session
            </button>
          )}
        </div>

        {/* STUDY REVIEW MODAL/PANEL */}
        {reviewMode && activeReviewItem && (
          <div className="rounded-3xl border-2 border-blue-100 bg-blue-50/30 p-6 sm:p-8 space-y-6 relative overflow-hidden animate-in fade-in duration-200">
            <div className="absolute top-0 right-0 p-4">
              <button 
                onClick={() => setReviewMode(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-white hover:text-slate-700 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="max-w-md mx-auto text-center space-y-6 py-4">
              <span className="text-[10px] font-extrabold text-blue-600 tracking-widest uppercase block">
                Study Review Session ({reviewIndex + 1} / {savedItems.length})
              </span>

              <div className="space-y-2">
                <h2 className="text-3xl sm:text-4xl font-black text-slate-900">{activeReviewItem.word}</h2>
                <p className="text-xs text-slate-400 italic">Level {activeReviewItem.level} • {activeReviewItem.wordType}</p>
              </div>

              {/* Show/Hide translation block */}
              <div className="min-h-[100px] flex items-center justify-center">
                {showAnswer ? (
                  <div className="p-5 bg-white rounded-2xl border border-blue-100 shadow-xs max-w-sm w-full animate-in zoom-in-95 duration-150">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase mb-1">Translation</span>
                    <p className="text-lg font-extrabold text-slate-950">{activeReviewItem.translation}</p>
                    {activeReviewItem.example1 && (
                      <p className="text-xs text-slate-500 mt-2 italic leading-relaxed">
                        &ldquo;{activeReviewItem.example1}&rdquo;
                      </p>
                    )}
                  </div>
                ) : (
                  <button
                    onClick={() => setShowAnswer(true)}
                    className="rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 border-dashed px-8 py-6 text-sm font-bold text-slate-600 transition flex items-center gap-2 shadow-xs"
                  >
                    <Eye className="h-4 w-4" />
                    Reveal Translation & Meaning
                  </button>
                )}
              </div>

              {/* Speak word helper */}
              <div className="flex justify-center gap-3">
                <button
                  onClick={() => speakWord(activeReviewItem.word)}
                  className="rounded-full bg-slate-900 hover:bg-slate-800 p-3 text-white transition"
                  title="Listen Audio"
                >
                  <Volume2 className="h-5 w-5" />
                </button>
              </div>

              {/* Steppers */}
              <div className="flex items-center justify-between pt-4 border-t border-blue-100">
                <button
                  onClick={() => {
                    setShowAnswer(false);
                    setReviewIndex(prev => Math.max(0, prev - 1));
                  }}
                  disabled={reviewIndex === 0}
                  className="text-xs font-bold text-slate-500 hover:text-slate-900 disabled:opacity-30"
                >
                  Previous
                </button>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleRemove(activeReviewItem.id)}
                    className="text-xs font-bold text-red-600 hover:bg-red-50 px-3 py-1.5 rounded-lg border border-red-100 transition"
                  >
                    Remove Saved
                  </button>
                </div>

                <button
                  onClick={() => {
                    setShowAnswer(false);
                    if (reviewIndex === savedItems.length - 1) {
                      setReviewMode(false);
                      alert("🎉 Review Session Finished! Well done keeping your vocabulary updated!");
                    } else {
                      setReviewIndex(prev => prev + 1);
                    }
                  }}
                  className="text-xs font-bold text-blue-600 hover:underline"
                >
                  {reviewIndex === savedItems.length - 1 ? "Finish Session" : "Next Card"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Search tool block */}
        {!reviewMode && (
          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 h-5 w-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search through saved translation or words..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-2xl border border-slate-200 pl-11 pr-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-none transition bg-white"
            />
          </div>
        )}

        {/* Saved words catalog */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-20 w-full bg-slate-200 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="rounded-3xl border border-slate-200 bg-white p-12 text-center shadow-xs">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-400 mb-4">
              <Heart className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-slate-800">Your saved list is empty</h3>
            <p className="text-slate-400 text-xs mt-1">
              {searchTerm 
                ? "No saved words match your current query." 
                : "Explore our vocabulary modules and click 'Save Word' to log cards here!"}
            </p>
            {!searchTerm && (
              <Link
                href="/vocabulary"
                className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:underline"
              >
                Go to Vocabulary Module
                <ArrowRight className="h-3 w-3" />
              </Link>
            )}
          </div>
        ) : (
          /* List of cards */
          <div className="space-y-3">
            {filteredItems.map((item) => (
              <div 
                key={item.id} 
                className="rounded-2xl border border-slate-200 bg-white p-4 hover:border-slate-300 shadow-2xs hover:shadow-xs transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  {/* Speech synthesis speaker icon */}
                  <button
                    onClick={() => speakWord(item.word)}
                    className="p-2.5 bg-slate-50 text-slate-600 hover:bg-blue-50 hover:text-blue-600 rounded-xl transition mt-0.5 shrink-0"
                    title="Pronounce word"
                  >
                    <Volume2 className="h-4.5 w-4.5" />
                  </button>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-bold text-slate-900">{item.word}</h3>
                      <span className="bg-slate-100 text-slate-500 font-semibold text-[9px] px-2 py-0.5 rounded-sm">
                        {item.level}
                      </span>
                      <span className="italic text-slate-400 text-xs">{item.wordType}</span>
                    </div>
                    <p className="text-sm font-bold text-blue-600 mt-0.5">{item.translation}</p>
                    {item.example1 && (
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed italic">
                        &ldquo;{item.example1}&rdquo;
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-end border-t sm:border-0 border-slate-100 pt-2 sm:pt-0 shrink-0">
                  <button
                    onClick={() => handleRemove(item.id)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 transition"
                    title="Remove from saved"
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </main>
    </div>
  );
}
