"use"

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { 
  User, Mail, Lock, ShieldCheck, Award, LogOut, Calendar, 
  Settings, Loader2, CheckCircle2, AlertCircle, Sparkles 
} from "lucide-react";
import Navbar from "@/components/Navbar";

const TARGET_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2", "IELTS"];

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Edit Profile form state
  const [fullName, setFullName] = useState("");
  const [targetLevel, setTargetLevel] = useState("A1");
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState("");
  const [profileError, setProfileError] = useState("");

  // Change Password state
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const router = useRouter();

  const fetchUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setFullName(data.user.fullName);
        setTargetLevel(data.user.level);
      } else {
        router.push("/login");
      }
    } catch (err) {
      router.push("/login");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess("");
    setProfileError("");

    if (!fullName || !targetLevel) {
      setProfileError("Full Name and Level are required");
      return;
    }

    setProfileSaving(true);

    try {
      const res = await fetch("/api/profile/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "update_profile",
          fullName,
          level: targetLevel,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setProfileSuccess("Profile settings successfully updated!");
        setUser(data.user);
      } else {
        setProfileError(data.error || "Failed to update profile settings.");
      }
    } catch {
      setProfileError("A connection error occurred.");
    } finally {
      setProfileSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordSuccess("");
    setPasswordError("");

    if (!currentPassword || !newPassword) {
      setPasswordError("Both current and new passwords are required.");
      return;
    }

    if (newPassword.length < 6) {
      setPasswordError("New password must be at least 6 characters long.");
      return;
    }

    setPasswordSaving(true);

    try {
      const res = await fetch("/api/profile/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "change_password",
          currentPassword,
          newPassword,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setPasswordSuccess("Password changed successfully!");
        setCurrentPassword("");
        setNewPassword("");
      } else {
        setPasswordError(data.error || "Failed to update password. Check old credentials.");
      }
    } catch {
      setPasswordError("A connection error occurred.");
    } finally {
      setPasswordSaving(false);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
          <p className="text-sm text-slate-500">Retrieving account settings...</p>
        </div>
      </div>
    );
  }

  const joinDate = user?.createdAt 
    ? new Date(user.createdAt).toLocaleDateString("en-US", { month: "long", year: "numeric", day: "numeric" })
    : "Recently";

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-16">
      <Navbar />

      <main className="mx-auto max-w-4xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        
        {/* Module Header */}
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
            <Settings className="h-6 w-6 text-blue-600" />
            My Account Settings
          </h1>
          <p className="text-slate-500 text-xs mt-1">
            Update personal info, adjust target language difficulty, and secure your login parameters.
          </p>
        </div>

        {/* User Stats Card */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row items-center sm:justify-between gap-6">
          <div className="flex items-center gap-4">
            <img
              src={user?.avatarUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user?.username}`}
              alt={user?.fullName}
              className="h-16 w-16 rounded-2xl bg-slate-100 object-cover"
            />
            <div>
              <h2 className="text-lg font-black text-slate-900">{user?.fullName}</h2>
              <p className="text-xs text-slate-500">@{user?.username} • {user?.email}</p>
              <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-400 font-semibold">
                <Calendar className="h-3.5 w-3.5 shrink-0" />
                Joined on {joinDate}
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center sm:items-end gap-1 shrink-0">
            <span className={`text-xs font-extrabold px-3 py-1 rounded-full ${
              user?.subscriptionPlan === "IELTS" 
                ? "bg-purple-100 text-purple-700 border border-purple-200"
                : user?.subscriptionPlan === "Basic"
                ? "bg-green-100 text-green-700 border border-green-200"
                : "bg-slate-100 text-slate-600 border border-slate-200"
            }`}>
              {user?.subscriptionPlan} Subscription
            </span>
            <button
              onClick={handleLogout}
              className="text-xs font-bold text-red-600 hover:underline flex items-center gap-1.5 mt-2"
            >
              <LogOut className="h-3.5 w-3.5" />
              Sign Out Account
            </button>
          </div>
        </div>

        {/* Edit and Password Forms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* PROFILE UPDATE FORM */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-950 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
              <User className="h-4.5 w-4.5 text-blue-600" />
              Edit Personal Profile
            </h3>

            <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Full Name</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-slate-900 focus:border-blue-600 outline-none transition text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">Target English Level Difficulty</label>
                <select
                  value={targetLevel}
                  onChange={(e) => setTargetLevel(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-slate-900 focus:border-blue-600 outline-none transition bg-white text-xs"
                >
                  {TARGET_LEVELS.map(lvl => (
                    <option key={lvl} value={lvl}>{lvl} Standard Level</option>
                  ))}
                </select>
              </div>

              {profileSuccess && (
                <div className="p-3 bg-green-50 text-green-700 font-semibold rounded-xl flex items-center gap-1.5 animate-in fade-in duration-150">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  {profileSuccess}
                </div>
              )}

              {profileError && (
                <div className="p-3 bg-red-50 text-red-600 font-semibold rounded-xl animate-in fade-in duration-150">
                  ⚠️ {profileError}
                </div>
              )}

              <button
                type="submit"
                disabled={profileSaving}
                className="w-full rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 transition disabled:opacity-40"
              >
                {profileSaving ? "Saving Settings..." : "Save Profile Details"}
              </button>
            </form>
          </div>

          {/* PASSWORD RESET FORM */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-950 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
              <Lock className="h-4.5 w-4.5 text-rose-500" />
              Secure Password Reset
            </h3>

            <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Current Account Password</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-slate-900 focus:border-blue-600 outline-none transition text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">New Account Password (Min 6 letters)</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-slate-900 focus:border-blue-600 outline-none transition text-xs"
                  required
                />
              </div>

              {passwordSuccess && (
                <div className="p-3 bg-green-50 text-green-700 font-semibold rounded-xl flex items-center gap-1.5 animate-in fade-in duration-150">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  {passwordSuccess}
                </div>
              )}

              {passwordError && (
                <div className="p-3 bg-red-50 text-red-600 font-semibold rounded-xl animate-in fade-in duration-150">
                  ⚠️ {passwordError}
                </div>
              )}

              <button
                type="submit"
                disabled={passwordSaving}
                className="w-full rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 transition disabled:opacity-40"
              >
                {passwordSaving ? "Updating Password..." : "Update Security Password"}
              </button>
            </form>
          </div>

        </div>

      </main>
    </div>
  );
}
