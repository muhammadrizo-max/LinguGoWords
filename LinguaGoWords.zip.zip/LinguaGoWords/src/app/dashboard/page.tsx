import React from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { savedWords, learnedWords, testResults } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { 
  BookOpen, BrainCircuit, Heart, Star, LayoutDashboard, Calendar,
  GraduationCap, Trophy, User, ArrowRight, Award, Zap, CheckCircle 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  // Fetch real database counts for the user
  const savedCountRes = await db
    .select({ count: sql<number>`count(*)` })
    .from(savedWords)
    .where(eq(savedWords.userId, user.id));
  const savedCount = Number(savedCountRes[0]?.count || 0);

  const learnedCountRes = await db
    .select({ count: sql<number>`count(*)` })
    .from(learnedWords)
    .where(eq(learnedWords.userId, user.id));
  const learnedCount = Number(learnedCountRes[0]?.count || 0);

  const testsCountRes = await db
    .select({ count: sql<number>`count(*)` })
    .from(testResults)
    .where(eq(testResults.userId, user.id));
  const testsCount = Number(testsCountRes[0]?.count || 0);

  const streak = user.streak || 0;
  const joinDate = user.createdAt 
    ? new Date(user.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric", day: "numeric" })
    : "Recently";

  // Menu cards data mapping
  const menuCards = [
    {
      title: "Vocabulary",
      desc: "Learn graded flashcards from A1 to IELTS with translations and pronunciation.",
      href: "/vocabulary",
      icon: BookOpen,
      color: "bg-blue-500",
      textColor: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      title: "Tests",
      desc: "Take multiple choice, translation, fill-in-the-blanks, or english writing tests.",
      href: "/tests",
      icon: GraduationCap,
      color: "bg-green-500",
      textColor: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      title: "Saved Words",
      desc: "Review, manage, search, and practice your saved vocabulary expressions.",
      href: "/saved",
      icon: Heart,
      color: "bg-rose-500",
      textColor: "text-rose-600",
      bgColor: "bg-rose-50"
    },
    {
      title: "Statistics",
      desc: "Examine detailed charts of your language progress, strengths, and test accuracies.",
      href: "/statistics",
      icon: LayoutDashboard,
      color: "bg-amber-500",
      textColor: "text-amber-600",
      bgColor: "bg-amber-50"
    },
    {
      title: "IELTS Section",
      desc: "Practice reading comprehension, writing tasks, and listening mock tests.",
      href: "/ielts",
      icon: Trophy,
      color: "bg-purple-500",
      textColor: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      title: "AI Mentor",
      desc: "Consult our advanced AI on grammar queries, sentence corrections, or speaking prompts.",
      href: "/mentor",
      icon: BrainCircuit,
      color: "bg-cyan-500",
      textColor: "text-cyan-600",
      bgColor: "bg-cyan-50"
    },
    {
      title: "Premium System",
      desc: "Upgrade plans to unlock C1, C2, and IELTS tiers, IELTS prep modules, and AI chatbot.",
      href: "/premium",
      icon: Star,
      color: "bg-yellow-500",
      textColor: "text-yellow-600",
      bgColor: "bg-yellow-50"
    },
    {
      title: "Profile",
      desc: "Update your name, target level, change passwords, and manage active sessions.",
      href: "/profile",
      icon: User,
      color: "bg-slate-700",
      textColor: "text-slate-700",
      bgColor: "bg-slate-100"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans pb-12">
      <Navbar />

      {/* Main Container */}
      <main className="mx-auto max-w-7xl w-full px-4 sm:px-6 lg:px-8 mt-8 space-y-8">
        
        {/* Welcome Header banner */}
        <section className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-blue-100 relative overflow-hidden">
          <div className="absolute -right-24 -bottom-24 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -left-12 -top-12 h-40 w-40 rounded-full bg-yellow-400/20 blur-2xl" />

          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
            <div className="flex items-center gap-4">
              <img
                src={user.avatarUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}`}
                alt={user.fullName}
                className="h-16 w-16 sm:h-20 sm:w-20 rounded-2xl bg-white/20 border-2 border-white/40 object-cover"
              />
              <div>
                <span className="inline-block bg-yellow-400 text-slate-950 font-extrabold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full mb-1 shadow-sm">
                  {user.level} TARGET LEVEL
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  Welcome Back, {user.fullName}!
                </h1>
                <p className="text-blue-100 text-xs sm:text-sm mt-1 flex items-center gap-1.5 font-medium">
                  <Calendar className="h-4 w-4 shrink-0 opacity-80" />
                  Learning with us since {joinDate} • Plan: <strong className="text-yellow-300 font-bold">{user.subscriptionPlan}</strong>
                </p>
              </div>
            </div>

            <Link
              href="/vocabulary"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-white text-blue-600 px-5 py-3 text-sm font-bold shadow-md hover:bg-slate-50 hover:scale-105 active:scale-95 transition"
            >
              Start Learning Now
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>

        {/* Real-time Statistics Cards Grid */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          
          {/* Stat 1: Learned Words */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs flex items-center gap-4">
            <div className="rounded-xl bg-green-50 p-3 text-green-600">
              <CheckCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Learned Words</p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">{learnedCount}</h3>
            </div>
          </div>

          {/* Stat 2: Saved Words */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs flex items-center gap-4">
            <div className="rounded-xl bg-rose-50 p-3 text-rose-500">
              <Heart className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Saved Words</p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">{savedCount}</h3>
            </div>
          </div>

          {/* Stat 3: Tests Completed */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs flex items-center gap-4">
            <div className="rounded-xl bg-indigo-50 p-3 text-indigo-600">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Tests Completed</p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">{testsCount}</h3>
            </div>
          </div>

          {/* Stat 4: Current Streak */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs flex items-center gap-4">
            <div className="rounded-xl bg-amber-50 p-3 text-amber-500">
              <Zap className="h-6 w-6 fill-amber-500" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Current Streak</p>
              <h3 className="text-2xl font-black text-slate-900 mt-1">{streak} {streak === 1 ? "day" : "days"}</h3>
            </div>
          </div>

        </section>

        {/* Modules Nav Menu Cards Grid */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold tracking-tight text-slate-900">Your Learning Modules</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {menuCards.map((card) => {
              const Icon = card.icon;
              return (
                <Link
                  key={card.href}
                  href={card.href}
                  className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs hover:shadow-md hover:border-slate-300 hover:scale-[1.02] active:scale-98 transition flex flex-col justify-between group text-left"
                >
                  <div>
                    <div className={`inline-flex rounded-xl ${card.bgColor} ${card.textColor} p-3 mb-4`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="text-base font-bold text-slate-950 group-hover:text-blue-600 transition">
                      {card.title}
                    </h3>
                    <p className="text-slate-500 text-xs mt-2 leading-relaxed">
                      {card.desc}
                    </p>
                  </div>

                  <div className="mt-4 flex items-center gap-1 text-xs font-bold text-slate-400 group-hover:text-blue-600 transition pt-2 border-t border-slate-50">
                    Open Module
                    <ArrowRight className="h-3 w-3 shrink-0" />
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

      </main>
    </div>
  );
}
