import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { aiUsageLogs, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

// Pre-defined expert answers for educational inquiries if no API key is set
function getEducationalFallbackResponse(userPrompt: string): string {
  const promptLower = userPrompt.toLowerCase();

  if (promptLower.includes("grammar") || promptLower.includes("rule") || promptLower.includes("tense") || promptLower.includes("present perfect")) {
    return `### 📘 English Grammar Guide

Here is a quick overview of one of the most common grammatical challenges: **Present Perfect vs. Past Simple**.

#### 1. Present Perfect (\`have/has + V3\`)
Used for actions that happened at an unspecified time in the past or have a direct connection to the present.
*   **Example:** *I have lost my keys.* (Meaning: I don't have them right now.)
*   **Key words:** *already, yet, since, for, ever, never, recently*.

#### 2. Past Simple (\`V2\`)
Used for completed actions in the past at a specific, known time.
*   **Example:** *I lost my keys yesterday.* (We know exactly when: yesterday.)
*   **Key words:** *yesterday, in 2020, 5 minutes ago, last week*.

---
**💡 Practice task:** 
*Try writing two sentences: one in Present Perfect about something you've done recently, and one in Past Simple about what you did last weekend! I will happily review them for you.*`;
  }

  if (promptLower.includes("ielts") || promptLower.includes("writing") || promptLower.includes("essay") || promptLower.includes("task 2")) {
    return `### 🏆 IELTS Academic Writing (Task 2) Band 7+ Blueprint

To achieve a Band 7 or higher in IELTS Writing Task 2, your essay must excel in four criteria:

1.  **Task Achievement (25%):** Address all parts of the prompt fully. State a clear position and support it with ideas.
2.  **Coherence & Cohesion (25%):** Organize your ideas into 4-5 paragraphs. Use linking words (*Furthermore, However, Consequently*).
3.  **Lexical Resource (25%):** Use a wide range of vocabulary. Instead of saying "important", use *crucial, fundamental, or paramount*.
4.  **Grammatical Range & Accuracy (25%):** Use a mix of simple, compound, and complex sentences.

#### 📝 Structure for an Opinion Essay:
*   **Introduction:** Paraphrase the prompt + state your clear opinion.
*   **Body Paragraph 1:** First argument supporting your opinion + explanation + concrete example.
*   **Body Paragraph 2:** Second argument supporting your opinion + explanation + concrete example.
*   **Conclusion:** Restate your opinion + summarize body arguments.

*Would you like to write a mock paragraph for a prompt? For example: "Should university education be free for everyone?" Write a paragraph and I will analyze and estimate its Band score!*`;
  }

  if (promptLower.includes("vocabulary") || promptLower.includes("word") || promptLower.includes("translate") || promptLower.includes("synonym")) {
    return `### 📚 Advanced Vocabulary Expansion

Let's upgrade your daily English expression list from simple (A1/A2) to IELTS level!

| Basic Word | Advanced/IELTS Synonym | Example Usage |
| :--- | :--- | :--- |
| **Big** | Substantial / Vast | The project requires a **substantial** amount of investment. |
| **Solve** | Alleviate / Resolve | New measures were introduced to **alleviate** the traffic issues. |
| **Bad** | Detrimental / Adverse | Smoking has a highly **detrimental** impact on physical health. |
| **Common** | Ubiquitous | Mobile phones have become **ubiquitous** in modern schools. |
| **Change** | Fluctuate | Prices of vegetables **fluctuate** based on weather conditions. |

*Which level of words (e.g. B2, C1, or IELTS) would you like to explore next? Name any topic (like "Business", "Environment", "Health") and I will provide you with cards!*`;
  }

  if (promptLower.includes("speaking") || promptLower.includes("pronounce") || promptLower.includes("accent")) {
    return `### 🗣️ IELTS Speaking Part 2 Strategy (The Cue Card)

In IELTS Speaking Part 2, you are given a topic card and have **1 minute to prepare** and **1-2 minutes to speak**.

#### 🚀 The PPF Technique (Past, Present, Future)
If you run out of things to say, divide your speech into time frames:
1.  **Past:** How did it start? How did you feel before?
2.  **Present:** Describe the current situation. What is happening now?
3.  **Future:** What are your plans regarding this topic in the future?

#### 🌟 Pro Tips:
*   Don't speak in short, clipped sentences. Use relative clauses (*"The place, which is located in northern Italy, was..."*).
*   Use fillers naturally to buy time instead of staying silent (*"Well, that's a fascinating question, let me think..."*).

*How about we do a mock cue card? Try answering this: "Describe a book you read recently that had a deep impact on you." Type your bullet points here!*`;
  }

  // General English Learner Greetings or answers
  return `### 👋 Hello! I am your AI English Mentor at LinguaGoWords!

I am here to guide you to your target language proficiency level (whether it's **A1-A2 basic English** or achieving a **Band 7+ in IELTS**).

Here are some things we can do together:
1.  **Grammar explanations:** Ask me to explain difficult rules, tenses, passive voice, or conditionals.
2.  **IELTS Prep:** Ask for Writing Task 1/2 outlines or Speaking strategies.
3.  **Vocabulary building:** Tell me a topic (e.g. "Workplace") and I will generate a list of advanced expressions.
4.  **Error correction:** Paste a text you wrote, and I will correct any mistakes and suggest higher-level synonyms.

*How can I help you in your English learning journey today?*`;
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check premium constraints
    if (user.subscriptionPlan === "Free") {
      return NextResponse.json(
        { error: "AI Mentor is a premium feature. Please upgrade to Basic or IELTS plan to unlock!" },
        { status: 403 }
      );
    }

    const { prompt, category = "General" } = await req.json();
    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 });
    }

    // Check system settings for custom AI prompt or model
    const settings = await db.select().from(systemSettings);
    const systemPromptSetting = settings.find(s => s.key === "ai_prompt")?.value || "You are an English language tutor.";
    const modelSetting = settings.find(s => s.key === "ai_model")?.value || "gpt-4o-mini";

    let aiResponseText = "";

    // 1. Check if OpenAI API Key is available
    if (process.env.OPENAI_API_KEY) {
      try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          },
          body: JSON.stringify({
            model: modelSetting,
            messages: [
              { role: "system", content: systemPromptSetting },
              { role: "user", content: prompt },
            ],
            temperature: 0.7,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          aiResponseText = data.choices[0]?.message?.content || "";
        } else {
          console.error("OpenAI API returned an error:", await response.text());
        }
      } catch (err) {
        console.error("Failed to query OpenAI:", err);
      }
    }

    // 2. Fallback to highly-intelligent mock responses if needed
    if (!aiResponseText) {
      aiResponseText = getEducationalFallbackResponse(prompt);
    }

    // 3. Log usage to db
    const logId = "log_" + Math.random().toString(36).substring(2, 11);
    await db.insert(aiUsageLogs).values({
      id: logId,
      userId: user.id,
      prompt: prompt,
      response: aiResponseText,
      category: category,
      createdAt: new Date(),
    });

    return NextResponse.json({
      success: true,
      response: aiResponseText,
    });
  } catch (error) {
    console.error("AI Mentor error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
