import { NextResponse } from "next/server";
import { db } from "@/db";
import { testQuestions, testResults } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const level = searchParams.get("level");
    const category = searchParams.get("category");

    let questions = await db.select().from(testQuestions);

    if (level && level !== "All") {
      questions = questions.filter(q => q.level.toLowerCase() === level.toLowerCase());
    }
    if (category && category !== "All") {
      questions = questions.filter(q => q.category.toLowerCase() === category.toLowerCase());
    }

    return NextResponse.json({ questions });
  } catch (error) {
    console.error("Fetch tests error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();

    // Check if it is an admin adding a question, or a user submitting a test result
    if (body.questionText) {
      // Admin adding a question
      if (user.role !== "admin" && user.role !== "super_admin") {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }

      const { type, questionText, options, correctAnswer, level, category } = body;
      if (!type || !questionText || !options || !correctAnswer || !level || !category) {
        return NextResponse.json({ error: "Missing fields" }, { status: 400 });
      }

      const id = "q_" + Math.random().toString(36).substring(2, 11);
      await db.insert(testQuestions).values({
        id,
        type,
        questionText,
        options,
        correctAnswer,
        level,
        category,
        createdAt: new Date(),
      });

      return NextResponse.json({ success: true, message: "Question created successfully" });
    } else {
      // User submitting test result
      const { score, totalQuestions, correctAnswers, wrongAnswers, accuracy, testType, level } = body;

      if (score === undefined || !totalQuestions || correctAnswers === undefined || wrongAnswers === undefined || accuracy === undefined || !testType || !level) {
        return NextResponse.json({ error: "Missing test result fields" }, { status: 400 });
      }

      const id = "tr_" + Math.random().toString(36).substring(2, 11);
      const newResult = {
        id,
        userId: user.id,
        score: Number(score),
        totalQuestions: Number(totalQuestions),
        correctAnswers: Number(correctAnswers),
        wrongAnswers: Number(wrongAnswers),
        accuracy: Number(accuracy),
        testType,
        level,
        createdAt: new Date(),
      };

      await db.insert(testResults).values(newResult);

      return NextResponse.json({ success: true, resultId: id });
    }
  } catch (error) {
    console.error("Submit test / add question error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const { id, type, questionText, options, correctAnswer, level, category } = body;

    if (!id || !type || !questionText || !options || !correctAnswer || !level || !category) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    await db
      .update(testQuestions)
      .set({
        type,
        questionText,
        options,
        correctAnswer,
        level,
        category,
      })
      .where(eq(testQuestions.id, id));

    return NextResponse.json({ success: true, message: "Question updated successfully" });
  } catch (error) {
    console.error("Edit question error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await db.delete(testQuestions).where(eq(testQuestions.id, id));

    return NextResponse.json({ success: true, message: "Question deleted successfully" });
  } catch (error) {
    console.error("Delete question error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
