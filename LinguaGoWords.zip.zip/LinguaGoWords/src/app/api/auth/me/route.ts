import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  // Remove password hash
  const { passwordHash: _, ...userSafe } = user;
  return NextResponse.json({ user: userSafe });
}
