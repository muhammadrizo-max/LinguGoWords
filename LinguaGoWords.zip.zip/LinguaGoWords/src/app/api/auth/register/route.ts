import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { hashPassword, signToken, setAuthCookie } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { fullName, username, email, password, confirmPassword } = await req.json();

    // 1. Validation
    if (!fullName || !username || !email || !password || !confirmPassword) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 });
    }

    if (username.length < 3) {
      return NextResponse.json({ error: "Username must be at least 3 characters long" }, { status: 400 });
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return NextResponse.json({ error: "Username can only contain letters, numbers, and underscores" }, { status: 400 });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Invalid email address" }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters long" }, { status: 400 });
    }

    if (password !== confirmPassword) {
      return NextResponse.json({ error: "Passwords do not match" }, { status: 400 });
    }

    // 2. Check existing user
    const existing = await db
      .select()
      .from(users)
      .where(or(eq(users.email, email.toLowerCase()), eq(users.username, username.toLowerCase())))
      .limit(1);

    if (existing.length > 0) {
      const u = existing[0];
      if (u.email.toLowerCase() === email.toLowerCase()) {
        return NextResponse.json({ error: "Email is already registered" }, { status: 400 });
      }
      return NextResponse.json({ error: "Username is already taken" }, { status: 400 });
    }

    // 3. Hash password and insert
    const hashedPassword = await hashPassword(password);
    const userId = "u_" + Math.random().toString(36).substring(2, 11);

    // Let's make "admin" user automatically admin, or set default role user
    const isDefaultAdmin = username.toLowerCase() === "admin" || email.toLowerCase() === "admin@linguagowords.com";
    const role = isDefaultAdmin ? "admin" : "user";

    const newUser = {
      id: userId,
      fullName,
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      passwordHash: hashedPassword,
      role: role,
      level: "A1",
      subscriptionPlan: "Free",
      streak: 0,
      banned: false,
      avatarUrl: `https://api.dicebear.com/7.x/adventurer/svg?seed=${username}`,
      createdAt: new Date(),
    };

    await db.insert(users).values(newUser);

    // 4. Set JWT cookie
    const token = signToken({
      userId: newUser.id,
      email: newUser.email,
      username: newUser.username,
      role: newUser.role,
    });

    await setAuthCookie(token);

    // Filter sensitive fields
    const { passwordHash: _, ...userSafe } = newUser;

    return NextResponse.json({
      message: "Registration successful",
      user: userSafe,
    });
  } catch (error: any) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
