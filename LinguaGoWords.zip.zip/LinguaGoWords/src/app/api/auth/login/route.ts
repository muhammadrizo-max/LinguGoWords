import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { comparePassword, signToken, setAuthCookie } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { identifier, password } = await req.json();

    if (!identifier || !password) {
      return NextResponse.json({ error: "Email/Username and password are required" }, { status: 400 });
    }

    // Find user by email or username
    const result = await db
      .select()
      .from(users)
      .where(or(eq(users.email, identifier.toLowerCase()), eq(users.username, identifier.toLowerCase())))
      .limit(1);

    if (result.length === 0) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 400 });
    }

    const user = result[0];

    if (user.banned) {
      return NextResponse.json({ error: "Your account has been banned. Please contact support." }, { status: 403 });
    }

    // Compare password
    const isPasswordCorrect = await comparePassword(password, user.passwordHash);
    if (!isPasswordCorrect) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 400 });
    }

    // Set JWT token in cookie
    const token = signToken({
      userId: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    });

    await setAuthCookie(token);

    // Update streak (randomly simulate, or increment if they log in)
    const newStreak = user.streak === 0 ? 1 : user.streak;
    await db.update(users).set({ streak: newStreak }).where(eq(users.id, user.id));

    // Exclude password hash from response
    const { passwordHash: _, ...userSafe } = user;
    userSafe.streak = newStreak;

    return NextResponse.json({
      message: "Login successful",
      user: userSafe,
    });
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
