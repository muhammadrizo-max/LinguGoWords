import { NextResponse } from "next/server";
import { getCurrentUser, signToken, setAuthCookie } from "@/lib/auth";
import { db } from "@/db";
import { users, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { accessCode } = await req.json();

    if (!accessCode) {
      return NextResponse.json({ error: "Access code is required" }, { status: 400 });
    }

    // 1. Fetch current access code from settings
    const result = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.key, "admin_access_code"))
      .limit(1);

    const expectedCode = result[0]?.value || "LinguaAdmin2026";

    if (accessCode !== expectedCode) {
      return NextResponse.json({ error: "Invalid Access Code" }, { status: 400 });
    }

    // 2. If the user is logged in, upgrade their role to 'admin' so they can access the panel!
    const currentUser = await getCurrentUser();
    if (currentUser) {
      if (currentUser.role !== "admin" && currentUser.role !== "super_admin") {
        await db
          .update(users)
          .set({ role: "admin" })
          .where(eq(users.id, currentUser.id));

        // Re-issue JWT cookie with updated role
        const token = signToken({
          userId: currentUser.id,
          email: currentUser.email,
          username: currentUser.username,
          role: "admin",
        });
        await setAuthCookie(token);
      }
    }

    return NextResponse.json({
      success: true,
      message: "Administrator access granted successfully",
    });
  } catch (error) {
    console.error("Admin verification error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
