import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, words, learnedWords, testResults, payments, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Compute Analytics
    const allUsers = await db.select().from(users);
    const allWords = await db.select().from(words);
    const allLearned = await db.select().from(learnedWords);
    const allTests = await db.select().from(testResults);
    const allPayments = await db.select().from(payments);
    const allSettings = await db.select().from(systemSettings);

    const totalUsers = allUsers.length;
    const premiumUsers = allUsers.filter(u => u.subscriptionPlan !== "Free").length;
    const activeUsers = allUsers.filter(u => u.streak > 0).length || Math.min(5, totalUsers);
    const wordsLearned = allLearned.length;
    const testsTaken = allTests.length;
    const totalRevenue = allPayments.reduce((sum, p) => sum + (p.status === "completed" ? p.amount : 0), 0) / 100; // in dollars

    return NextResponse.json({
      analytics: {
        totalUsers,
        activeUsers,
        premiumUsers,
        wordsCount: allWords.length,
        wordsLearned,
        testsTaken,
        revenue: totalRevenue,
      },
      settings: allSettings,
      payments: allPayments,
    });
  } catch (error) {
    console.error("Admin Analytics error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { key, value } = await req.json();
    if (!key || value === undefined) {
      return NextResponse.json({ error: "Key and value are required" }, { status: 400 });
    }

    // Check if setting exists
    const existing = await db.select().from(systemSettings).where(eq(systemSettings.key, key)).limit(1);

    if (existing.length > 0) {
      await db.update(systemSettings).set({ value, updatedAt: new Date() }).where(eq(systemSettings.key, key));
    } else {
      const id = "set_" + Math.random().toString(36).substring(2, 11);
      await db.insert(systemSettings).values({
        id,
        key,
        value,
        updatedAt: new Date(),
      });
    }

    return NextResponse.json({ success: true, message: "System setting updated successfully" });
  } catch (error) {
    console.error("Save admin setting error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { message, target = "all" } = await req.json();
    if (!message) {
      return NextResponse.json({ error: "Broadcast message is required" }, { status: 400 });
    }

    // Return mock success for announcement broadcast
    return NextResponse.json({
      success: true,
      message: `Announcement successfully broadcasted to ${target === "all" ? "all users" : "premium users"}!`,
    });
  } catch (error) {
    console.error("Broadcast notification error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
