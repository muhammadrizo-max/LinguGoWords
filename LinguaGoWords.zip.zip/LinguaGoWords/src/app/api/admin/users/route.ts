import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, payments, subscriptions, savedWords, learnedWords, testResults } from "@/db/schema";
import { eq, or, like, and, not } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") || "";

    let allUsers = await db.select().from(users);

    if (search) {
      const lowerSearch = search.toLowerCase();
      allUsers = allUsers.filter(
        u =>
          u.fullName.toLowerCase().includes(lowerSearch) ||
          u.username.toLowerCase().includes(lowerSearch) ||
          u.email.toLowerCase().includes(lowerSearch)
      );
    }

    // Exclude password hashes
    const sanitizedUsers = allUsers.map(({ passwordHash, ...rest }) => rest);

    return NextResponse.json({ users: sanitizedUsers });
  } catch (error) {
    console.error("Admin Users GET error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const adminUser = await getCurrentUser();
    if (!adminUser || (adminUser.role !== "admin" && adminUser.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const { userId, action, role, subscriptionPlan, banned } = body;

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 });
    }

    // Don't let an admin ban/modify their own account
    if (userId === adminUser.id) {
      return NextResponse.json({ error: "You cannot modify your own administrator account" }, { status: 400 });
    }

    if (action === "update_role" && role) {
      await db.update(users).set({ role }).where(eq(users.id, userId));
      return NextResponse.json({ success: true, message: "User role updated successfully" });
    }

    if (action === "update_plan" && subscriptionPlan) {
      const expiresAt = subscriptionPlan === "Free" ? null : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
      await db
        .update(users)
        .set({ subscriptionPlan, subscriptionExpiresAt: expiresAt })
        .where(eq(users.id, userId));
      return NextResponse.json({ success: true, message: "User subscription plan updated successfully" });
    }

    if (action === "toggle_ban" && banned !== undefined) {
      await db.update(users).set({ banned: !!banned }).where(eq(users.id, userId));
      return NextResponse.json({ success: true, message: banned ? "User banned successfully" : "User unbanned successfully" });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Admin Users PUT error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const adminUser = await getCurrentUser();
    if (!adminUser || (adminUser.role !== "admin" && adminUser.role !== "super_admin")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("id");

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 });
    }

    if (userId === adminUser.id) {
      return NextResponse.json({ error: "You cannot delete yourself" }, { status: 400 });
    }

    // Delete related records to prevent foreign key errors
    await db.delete(savedWords).where(eq(savedWords.userId, userId));
    await db.delete(learnedWords).where(eq(learnedWords.userId, userId));
    await db.delete(testResults).where(eq(testResults.userId, userId));
    await db.delete(payments).where(eq(payments.userId, userId));
    await db.delete(subscriptions).where(eq(subscriptions.userId, userId));

    // Delete the user
    await db.delete(users).where(eq(users.id, userId));

    return NextResponse.json({ success: true, message: "User and all associated data deleted successfully" });
  } catch (error) {
    console.error("Admin Users DELETE error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
