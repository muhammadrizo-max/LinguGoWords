import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { learnedWords } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { wordId, action } = await req.json();
    if (!wordId || !action) {
      return NextResponse.json({ error: "Word ID and action are required" }, { status: 400 });
    }

    if (action === "learn") {
      // Check if already learned
      const existing = await db
        .select()
        .from(learnedWords)
        .where(and(eq(learnedWords.userId, user.id), eq(learnedWords.wordId, wordId)))
        .limit(1);

      if (existing.length === 0) {
        const id = "lw_" + Math.random().toString(36).substring(2, 11);
        await db.insert(learnedWords).values({
          id,
          userId: user.id,
          wordId,
          createdAt: new Date(),
        });
      }
      return NextResponse.json({ success: true, learned: true });
    } else if (action === "unlearn") {
      await db
        .delete(learnedWords)
        .where(and(eq(learnedWords.userId, user.id), eq(learnedWords.wordId, wordId)));
      return NextResponse.json({ success: true, learned: false });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Mark learned error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
