import { NextResponse } from "next/server";
import { db } from "@/db";
import { words, savedWords, learnedWords } from "@/db/schema";
import { eq, and, or } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const level = searchParams.get("level");
    const category = searchParams.get("category");
    const wordId = searchParams.get("wordId");

    // Get current user for saved/learned state
    const user = await getCurrentUser();

    // 1. Fetch single word details
    if (wordId) {
      const result = await db.select().from(words).where(eq(words.id, wordId)).limit(1);
      if (result.length === 0) {
        return NextResponse.json({ error: "Word not found" }, { status: 404 });
      }
      return NextResponse.json({ word: result[0] });
    }

    // 2. Fetch list
    let queryResult = await db.select().from(words);

    // Apply filtering in JavaScript for ease of multi-parameter options
    if (level && level !== "All" && level !== "") {
      queryResult = queryResult.filter(w => w.level.toLowerCase() === level.toLowerCase());
    }
    if (category && category !== "All" && category !== "") {
      queryResult = queryResult.filter(w => w.category.toLowerCase() === category.toLowerCase());
    }

    // If user logged in, fetch saved and learned words to attach flag
    let savedWordIds: string[] = [];
    let learnedWordIds: string[] = [];

    if (user) {
      const saved = await db.select().from(savedWords).where(eq(savedWords.userId, user.id));
      const learned = await db.select().from(learnedWords).where(eq(learnedWords.userId, user.id));
      savedWordIds = saved.map(s => s.wordId);
      learnedWordIds = learned.map(l => l.wordId);
    }

    const wordsWithState = queryResult.map(w => ({
      ...w,
      isSaved: savedWordIds.includes(w.id),
      isLearned: learnedWordIds.includes(w.id),
    }));

    return NextResponse.json({ words: wordsWithState });
  } catch (error) {
    console.error("Vocabulary GET error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Unauthorized. Admin role required." }, { status: 403 });
    }

    const body = await req.json();
    const { word, translation, pronunciation, wordType, example1, example2, level, category } = body;

    if (!word || !translation || !pronunciation || !wordType || !level || !category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const id = "w_" + Math.random().toString(36).substring(2, 11);
    const newWord = {
      id,
      word,
      translation,
      pronunciation,
      wordType,
      example1: example1 || "",
      example2: example2 || "",
      level,
      category,
      createdAt: new Date(),
    };

    await db.insert(words).values(newWord);

    return NextResponse.json({ success: true, word: newWord });
  } catch (error) {
    console.error("Vocabulary POST error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Unauthorized. Admin role required." }, { status: 403 });
    }

    const body = await req.json();
    const { id, word, translation, pronunciation, wordType, example1, example2, level, category } = body;

    if (!id || !word || !translation || !pronunciation || !wordType || !level || !category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    await db
      .update(words)
      .set({
        word,
        translation,
        pronunciation,
        wordType,
        example1,
        example2,
        level,
        category,
      })
      .where(eq(words.id, id));

    return NextResponse.json({ success: true, message: "Word updated successfully" });
  } catch (error) {
    console.error("Vocabulary PUT error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
      return NextResponse.json({ error: "Unauthorized. Admin role required." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    // Delete in saved_words and learned_words first to maintain database integrity
    await db.delete(savedWords).where(eq(savedWords.wordId, id));
    await db.delete(learnedWords).where(eq(learnedWords.wordId, id));
    // Now delete the word
    await db.delete(words).where(eq(words.id, id));

    return NextResponse.json({ success: true, message: "Word deleted successfully" });
  } catch (error) {
    console.error("Vocabulary DELETE error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
