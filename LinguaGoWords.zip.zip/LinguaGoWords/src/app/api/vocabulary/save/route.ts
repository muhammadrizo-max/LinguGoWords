import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { savedWords } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { wordId, action } = await req.json();
    if (!wordId || !action) {
      return NextResponse.json({ error: "Word ID and action are required" }, { status: 400 });
    }

    if (action === "save") {
      // Check if already saved
      const existing = await db
        .select()
        .from(savedWords)
        .where(and(eq(savedWords.userId, user.id), eq(savedWords.wordId, wordId)))
        .limit(1);

      if (existing.length === 0) {
        const id = "sw_" + Math.random().toString(36).substring(2, 11);
        await db.insert(savedWords).values({
          id,
          userId: user.id,
          wordId,
          createdAt: new Date(),
        });
      }
      return NextResponse.json({ success: true, saved: true });
    } else if (action === "unsave") {
      await db
        .delete(savedWords)
        .where(and(eq(savedWords.userId, user.id), eq(savedWords.wordId, wordId)));
      return NextResponse.json({ success: true, saved: false });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Save word error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
