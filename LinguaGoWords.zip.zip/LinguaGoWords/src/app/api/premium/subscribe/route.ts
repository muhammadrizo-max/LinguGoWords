import { NextResponse } from "next/server";
import { getCurrentUser, signToken, setAuthCookie } from "@/lib/auth";
import { db } from "@/db";
import { users, payments, subscriptions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { plan } = await req.json();
    if (!plan || !["Free", "Basic", "IELTS"].includes(plan)) {
      return NextResponse.json({ error: "Invalid plan selected" }, { status: 400 });
    }

    // Set expiration date (1 year from now, or null for Free)
    const expiresAt = plan === "Free" ? null : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
    const cost = plan === "Free" ? 0 : plan === "Basic" ? 999 : 2499; // in cents ($9.99 or $24.99)

    // 1. Update user table
    await db
      .update(users)
      .set({
        subscriptionPlan: plan,
        subscriptionExpiresAt: expiresAt,
      })
      .where(eq(users.id, user.id));

    // 2. Insert payment record if not free
    if (plan !== "Free") {
      const paymentId = "pay_" + Math.random().toString(36).substring(2, 11);
      await db.insert(payments).values({
        id: paymentId,
        userId: user.id,
        amount: cost,
        currency: "USD",
        plan: plan,
        status: "completed",
        createdAt: new Date(),
      });

      // 3. Insert active subscription record
      const subId = "sub_" + Math.random().toString(36).substring(2, 11);
      await db.insert(subscriptions).values({
        id: subId,
        userId: user.id,
        plan: plan,
        status: "active",
        amount: cost,
        createdAt: new Date(),
        expiresAt: expiresAt,
      });
    }

    // 4. Update the user session cookie with the new plan
    const token = signToken({
      userId: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    });
    await setAuthCookie(token);

    return NextResponse.json({
      success: true,
      plan: plan,
      expiresAt: expiresAt,
      message: `Successfully updated to the ${plan} plan!`,
    });
  } catch (error) {
    console.error("Subscription update error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
