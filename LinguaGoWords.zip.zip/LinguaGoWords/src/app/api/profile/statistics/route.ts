import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { savedWords, learnedWords, testResults } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // 1. Fetch counts
    const savedCountRes = await db
      .select({ count: sql<number>`count(*)` })
      .from(savedWords)
      .where(eq(savedWords.userId, user.id));
    const savedCount = Number(savedCountRes[0]?.count || 0);

    const learnedCountRes = await db
      .select({ count: sql<number>`count(*)` })
      .from(learnedWords)
      .where(eq(learnedWords.userId, user.id));
    const learnedCount = Number(learnedCountRes[0]?.count || 0);

    const testsCountRes = await db
      .select({ count: sql<number>`count(*)` })
      .from(testResults)
      .where(eq(testResults.userId, user.id));
    const testsCount = Number(testsCountRes[0]?.count || 0);

    // 2. Fetch test history
    const history = await db
      .select()
      .from(testResults)
      .where(eq(testResults.userId, user.id))
      .orderBy(sql`created_at desc`);

    // 3. Compute accuracy rate
    let totalAccuracySum = 0;
    history.forEach(item => {
      totalAccuracySum += item.accuracy;
    });
    const avgAccuracy = history.length > 0 ? Math.round(totalAccuracySum / history.length) : 0;

    return NextResponse.json({
      savedCount,
      learnedCount,
      testsCount,
      streak: user.streak,
      avgAccuracy,
      history,
    });
  } catch (error) {
    console.error("Personal stats error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
