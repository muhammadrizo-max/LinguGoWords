import { NextResponse } from "next/server";
import { getCurrentUser, comparePassword, hashPassword } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { action, fullName, level, currentPassword, newPassword } = body;

    if (action === "update_profile") {
      if (!fullName || !level) {
        return NextResponse.json({ error: "Full Name and Level are required" }, { status: 400 });
      }

      const avatarUrl = `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}&hairColor=b16a40&eyebrows=variant04&mouth=smile`;

      await db
        .update(users)
        .set({
          fullName,
          level,
          avatarUrl,
        })
        .where(eq(users.id, user.id));

      return NextResponse.json({
        success: true,
        message: "Profile updated successfully",
        user: { ...user, fullName, level, avatarUrl },
      });
    } else if (action === "change_password") {
      if (!currentPassword || !newPassword) {
        return NextResponse.json({ error: "Current password and new password are required" }, { status: 400 });
      }

      if (newPassword.length < 6) {
        return NextResponse.json({ error: "New password must be at least 6 characters long" }, { status: 400 });
      }

      const isPasswordCorrect = await comparePassword(currentPassword, user.passwordHash);
      if (!isPasswordCorrect) {
        return NextResponse.json({ error: "Incorrect current password" }, { status: 400 });
      }

      const newHash = await hashPassword(newPassword);
      await db
        .update(users)
        .set({
          passwordHash: newHash,
        })
        .where(eq(users.id, user.id));

      return NextResponse.json({
        success: true,
        message: "Password changed successfully",
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Profile update error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
