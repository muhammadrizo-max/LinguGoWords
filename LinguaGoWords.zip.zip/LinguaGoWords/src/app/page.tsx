import React from "react";
import Link from "next/link";
import { 
  Award, BrainCircuit, GraduationCap, Heart, Star, 
  ArrowRight, Sparkles, BookOpen, Shield, CheckCircle2, Trophy 
} from "lucide-react";
import Navbar from "@/components/Navbar";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 sm:py-28 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-blue-50/70 via-white to-slate-50">
        <div className="absolute top-0 left-1/2 -z-10 -translate-x-1/2 blur-3xl xl:-top-6">
          <div
            className="aspect-[1155/678] w-[72.1875rem] bg-gradient-to-tr from-[#2563EB] to-[#22C55E] opacity-15"
            style={{
              clipPath:
                "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
            }}
          />
        </div>

        <div className="mx-auto max-w-5xl text-center">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700 mb-6 border border-blue-100">
            <Sparkles className="h-3.5 w-3.5" />
            Learn vocabulary efficiently from Telegram bot to Web!
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Master English Vocabulary <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-500">
              From A1 to IELTS Level
            </span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Welcome to <strong>LinguaGoWords</strong>. Explore interactive flashcards, track progress, challenge yourself with grammar tests, practice real IELTS scenarios, and consult your personal AI Mentor.
          </p>

          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Link
              href="/register"
              className="inline-flex items-center gap-2 rounded-2xl bg-blue-600 px-8 py-4 text-base font-bold text-white shadow-lg shadow-blue-200 hover:bg-blue-700 hover:scale-[1.02] active:scale-95 transition"
            >
              Get Started Free
              <ArrowRight className="h-5 w-5" />
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-2xl bg-white border border-slate-200 px-8 py-4 text-base font-bold text-slate-700 shadow-xs hover:bg-slate-50 transition"
            >
              Sign In
            </Link>
          </div>

          {/* Quick stats tags */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-4 text-sm font-semibold text-slate-500">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4.5 w-4.5 text-green-500" />
              100% Free Trial
            </span>
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4.5 w-4.5 text-green-500" />
              AI-Powered Mentor
            </span>
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4.5 w-4.5 text-green-500" />
              Comprehensive IELTS Modules
            </span>
          </div>
        </div>
      </section>

      {/* Feature Blocks */}
      <section className="py-16 sm:py-24 bg-white border-y border-slate-100">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Engineered for Fluent Progress
            </h2>
            <p className="mt-4 text-base sm:text-lg text-slate-500">
              LinguaGoWords covers essential, colloquial, and academic English with scientifically designed practice modules.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="rounded-2xl border border-slate-100 bg-slate-50/50 p-8 hover:shadow-lg transition">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md mb-6">
                <BookOpen className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Graded Vocabulary</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Structured lexical cards graded from A1, A2, B1, B2, C1, C2 to professional IELTS requirements. Complete with IPA pronunciation, meanings, and practical examples.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="rounded-2xl border border-slate-100 bg-slate-50/50 p-8 hover:shadow-lg transition">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500 text-white shadow-md mb-6">
                <GraduationCap className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Interactive Tests</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Challenge your memory with Multiple Choice, Translation, Fill-In-The-Blanks, and Write in English assignments. Real-time accuracy metrics logged to the database.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="rounded-2xl border border-slate-100 bg-slate-50/50 p-8 hover:shadow-lg transition">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-600 text-white shadow-md mb-6">
                <BrainCircuit className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">24/7 AI Tutor</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Unlock instant grammar explanations, vocabulary checks, and personalized writing evaluation from the built-in AI mentor. Always ready to guide you.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Levels and IELTS Showcase */}
      <section className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <div className="rounded-3xl bg-slate-900 text-white p-8 sm:p-12 shadow-2xl relative overflow-hidden">
            <div className="absolute -right-10 -bottom-10 h-40 w-40 rounded-full bg-blue-600 opacity-20 blur-2xl" />
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-green-500 opacity-20 blur-2xl" />

            <div className="max-w-2xl">
              <span className="text-xs font-bold uppercase tracking-wider text-green-400">Targeted Exam Preparation</span>
              <h3 className="mt-2 text-3xl font-extrabold sm:text-4xl">IELTS Specialized Training</h3>
              <p className="mt-4 text-slate-300 leading-relaxed text-sm sm:text-base">
                Our platform delivers structured exercises for IELTS Reading, Writing, Listening, and Speaking modules. Perfect your answers, explore band-boosting collocations, and pass with flying colors.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <span className="rounded-lg bg-white/10 px-3 py-1 text-xs font-bold">Reading Matches</span>
                <span className="rounded-lg bg-white/10 px-3 py-1 text-xs font-bold">Writing Essays</span>
                <span className="rounded-lg bg-white/10 px-3 py-1 text-xs font-bold">Listening Audio Mock</span>
                <span className="rounded-lg bg-white/10 px-3 py-1 text-xs font-bold">Speaking Cue Cards</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Simple Pricing Section */}
      <section className="py-16 sm:py-24 bg-slate-50 border-t border-slate-100">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900">Subscription Plans</h2>
            <p className="mt-3 text-slate-500">Pick the level of access you need to unlock fluent proficiency</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            
            {/* Free */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Free Tier</h3>
                <p className="text-xs text-slate-500 mt-1">Excellent for getting started</p>
                <div className="mt-4 text-3xl font-black text-slate-900">$0<span className="text-sm font-normal text-slate-500">/ forever</span></div>
                <ul className="mt-6 space-y-3 text-xs text-slate-600">
                  <li className="flex items-center gap-2">✔️ Full Access to level **A1**</li>
                  <li className="flex items-center gap-2">✔️ General Category vocabulary</li>
                  <li className="flex items-center gap-2">✔️ Basic Multiple Choice Tests</li>
                  <li className="text-slate-400 line-through">❌ A2, B1, B2, C1, C2 & IELTS</li>
                  <li className="text-slate-400 line-through">❌ Premium AI Mentor</li>
                  <li className="text-slate-400 line-through">❌ Complete IELTS Modules</li>
                </ul>
              </div>
              <Link href="/register" className="mt-8 block w-full text-center rounded-xl bg-slate-100 py-3 text-xs font-bold text-slate-700 hover:bg-slate-200 transition">
                Start Learning
              </Link>
            </div>

            {/* Basic */}
            <div className="rounded-2xl border-2 border-blue-600 bg-white p-6 shadow-md relative flex flex-col justify-between">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-blue-600 px-3 py-0.5 text-[10px] font-extrabold text-white uppercase tracking-wider">
                Recommended
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Basic Premium</h3>
                <p className="text-xs text-slate-500 mt-1">Accelerate standard fluency</p>
                <div className="mt-4 text-3xl font-black text-slate-900">$9.99<span className="text-sm font-normal text-slate-500">/ year</span></div>
                <ul className="mt-6 space-y-3 text-xs text-slate-600">
                  <li className="flex items-center gap-2">✔️ Access levels **A1, A2, and B1**</li>
                  <li className="flex items-center gap-2">✔️ All Vocabulary Categories</li>
                  <li className="flex items-center gap-2">✔️ Word saving & learning stats</li>
                  <li className="flex items-center gap-2">✔️ Review & Repeat cards</li>
                  <li className="text-slate-400 line-through">❌ C1, C2 & IELTS levels</li>
                  <li className="text-slate-400 line-through">❌ Premium AI Mentor</li>
                </ul>
              </div>
              <Link href="/register" className="mt-8 block w-full text-center rounded-xl bg-blue-600 py-3 text-xs font-bold text-white hover:bg-blue-700 transition">
                Upgrade Now
              </Link>
            </div>

            {/* IELTS Plan */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">IELTS Master</h3>
                <p className="text-xs text-slate-500 mt-1">Maximum prep efficiency</p>
                <div className="mt-4 text-3xl font-black text-slate-900">$24.99<span className="text-sm font-normal text-slate-500">/ year</span></div>
                <ul className="mt-6 space-y-3 text-xs text-slate-600">
                  <li className="flex items-center gap-2">✔️ **All Levels** unlocked (A1 to IELTS)</li>
                  <li className="flex items-center gap-2">✔️ **AI Mentor** unlocked (Grammar & feedback)</li>
                  <li className="flex items-center gap-2">✔️ **IELTS Modules** (Reading, Writing, Listening)</li>
                  <li className="flex items-center gap-2">✔️ Saved Words lists & Review tools</li>
                  <li className="flex items-center gap-2">✔️ Full Mock Tests & Database tracking</li>
                  <li className="flex items-center gap-2">✔️ Interactive charts</li>
                </ul>
              </div>
              <Link href="/register" className="mt-8 block w-full text-center rounded-xl bg-slate-900 py-3 text-xs font-bold text-white hover:bg-slate-850 transition">
                Go IELTS Pro
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-8 text-center text-xs text-slate-400">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p>© 2026 LinguaGoWords. Based on existing educational Telegram bot system. Built with Next.js & Drizzle ORM.</p>
          <p className="mt-2 text-[10px]">
            Tip: Operators may access system admin functions by clicking the logo 5 times.
          </p>
        </div>
      </footer>
    </div>
  );
}
