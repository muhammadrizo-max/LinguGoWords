"use"

"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Award, Mail, Lock, LogIn, Loader2, Info } from "lucide-react";

export default function LoginPage() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [forgotPasswordMsg, setForgotPasswordMsg] = useState("");
  
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setForgotPasswordMsg("");

    if (!identifier || !password) {
      setError("Please fill in all fields");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier,
          password,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Invalid username or password");
      } else {
        setSuccess("Login successful! Welcome back!");
        
        // Simulating remember me
        if (rememberMe) {
          localStorage.setItem("remembered_username", identifier);
        } else {
          localStorage.removeItem("remembered_username");
        }

        setTimeout(() => {
          router.push("/dashboard");
          router.refresh();
        }, 1200);
      }
    } catch (err) {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = () => {
    if (!identifier) {
      setError("Please enter your Username or Email in the field above first.");
    } else {
      setForgotPasswordMsg(`A recovery code has been sent to the email associated with "${identifier}". (Simulated)`);
      setError("");
    }
  };

  return (
    <main className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 font-sans">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
        {/* Header styling */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-8 text-center text-white">
          <Link href="/" className="inline-flex items-center gap-2 mb-2 group">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20 text-white transition group-hover:scale-105">
              <Award className="h-6 w-6 text-yellow-300" />
            </div>
            <span className="text-xl font-black tracking-tight text-white leading-none">
              LinguaGo<span className="text-yellow-300">Words</span>
            </span>
          </Link>
          <h2 className="text-xl font-bold">Welcome Back</h2>
          <p className="text-xs text-blue-100 mt-1">Ready to learn some new English vocabulary today?</p>
        </div>

        {/* Demo Credentials Info Alert */}
        <div className="m-6 mb-0 p-3 bg-blue-50 border border-blue-100 rounded-xl text-[11px] text-blue-700 flex gap-2">
          <Info className="h-4 w-4 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">✨ Quick Demo Operator Account:</p>
            <p>Username: <code className="font-bold">admin</code> | Password: <code className="font-bold">adminpassword</code></p>
            <p className="mt-1">Or register a fresh new account to experience the platform.</p>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="p-6 sm:p-8 space-y-4">
          
          {/* Email or Username identifier */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
              Email or Username
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
              <input
                type="text"
                placeholder="admin or email@example.com"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                className="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-none transition"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Password
              </label>
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-xs font-bold text-blue-600 hover:underline"
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
              <input
                type="password"
                placeholder="••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-none transition"
                required
              />
            </div>
          </div>

          {/* Remember Me */}
          <div className="flex items-center">
            <input
              id="remember-me"
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="h-4 w-4 rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="remember-me" className="ml-2 block text-xs text-slate-600 font-medium cursor-pointer">
              Remember Me
            </label>
          </div>

          {error && (
            <div className="rounded-xl bg-red-50 p-3.5 text-xs font-semibold text-red-600">
              ⚠️ {error}
            </div>
          )}

          {success && (
            <div className="rounded-xl bg-green-50 p-3.5 text-xs font-semibold text-green-700">
              ✨ {success}
            </div>
          )}

          {forgotPasswordMsg && (
            <div className="rounded-xl bg-blue-50 p-3.5 text-xs font-medium text-blue-700">
              📬 {forgotPasswordMsg}
            </div>
          )}

          <div className="flex flex-col gap-2 pt-2">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white shadow-md shadow-blue-200 hover:bg-blue-700 hover:scale-[1.01] active:scale-95 transition disabled:opacity-50"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Verifying Account...
                </>
              ) : (
                <>
                  <LogIn className="h-4 w-4" />
                  Sign In
                </>
              )}
            </button>

            <Link
              href="/register"
              className="w-full text-center rounded-xl border border-slate-200 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50 transition"
            >
              Create Free Account
            </Link>
          </div>
        </form>
      </div>
    </main>
  );
}
